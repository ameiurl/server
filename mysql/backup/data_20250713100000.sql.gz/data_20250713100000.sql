-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: gogs
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  `mode` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_access_s` (`user_id`,`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access`
--

LOCK TABLES `access` WRITE;
/*!40000 ALTER TABLE `access` DISABLE KEYS */;
INSERT INTO `access` VALUES (1,1,2,4),(2,1,3,4),(3,1,4,4),(4,1,5,4),(5,1,6,4),(6,1,7,4),(7,1,8,4),(8,1,9,4),(9,1,10,4),(10,1,11,4),(11,1,12,4),(12,1,13,4),(13,1,14,4),(14,1,15,4),(15,1,16,4),(16,1,17,4),(17,1,18,4),(18,1,19,4),(19,1,20,4),(20,1,21,4),(21,1,22,4),(22,1,23,4),(23,1,24,4),(24,1,25,4),(25,1,26,4),(26,1,27,4),(27,1,28,4),(28,1,29,4),(29,1,30,4),(30,1,31,4),(31,1,32,4),(32,1,33,4),(33,1,34,4),(34,1,35,4),(35,1,36,4),(36,1,37,4),(37,1,38,4),(38,1,39,4),(39,1,40,4),(40,1,41,4),(41,1,43,4),(42,1,44,4),(43,1,46,4),(44,1,47,4),(45,1,48,4),(46,1,49,4),(47,1,51,4),(48,1,53,4),(49,1,54,4),(50,1,55,4),(51,1,56,4),(52,1,57,4),(53,1,58,4),(54,1,59,4),(55,1,60,4),(56,1,61,4);
/*!40000 ALTER TABLE `access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_token`
--

DROP TABLE IF EXISTS `access_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_token` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sha1` varchar(40) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  `sha256` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha256` (`sha256`),
  UNIQUE KEY `UQE_access_token_sha1` (`sha1`),
  KEY `IDX_access_token_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_token`
--

LOCK TABLES `access_token` WRITE;
/*!40000 ALTER TABLE `access_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `op_type` int DEFAULT NULL,
  `act_user_id` bigint DEFAULT NULL,
  `act_user_name` varchar(255) DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  `repo_user_name` varchar(255) DEFAULT NULL,
  `repo_name` varchar(255) DEFAULT NULL,
  `ref_name` varchar(255) DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `content` text,
  `created_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_action_repo_id` (`repo_id`),
  KEY `idx_action_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` VALUES (2,1,1,1,'chenms',2,'butterfly','autoloading','',0,'',1572916822),(3,2,1,1,'chenms',2,'butterfly','autoloading','',0,'',1572916822),(4,1,16,1,'chenms',2,'butterfly','autoloading','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e53241e9b6bc561324310287cc12debe3db5280e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T09:23:16+08:00\"}],\"CompareURL\":\"\"}',1572917029),(5,2,16,1,'chenms',2,'butterfly','autoloading','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e53241e9b6bc561324310287cc12debe3db5280e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T09:23:16+08:00\"}],\"CompareURL\":\"\"}',1572917029),(6,1,5,1,'chenms',2,'butterfly','autoloading','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e53241e9b6bc561324310287cc12debe3db5280e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T09:23:16+08:00\"}],\"CompareURL\":\"\"}',1572917029),(7,2,5,1,'chenms',2,'butterfly','autoloading','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e53241e9b6bc561324310287cc12debe3db5280e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T09:23:16+08:00\"}],\"CompareURL\":\"\"}',1572917029),(8,1,1,1,'chenms',3,'butterfly','cache','',0,'',1572932637),(9,2,1,1,'chenms',3,'butterfly','cache','',0,'',1572932637),(10,1,16,1,'chenms',3,'butterfly','cache','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"62ecd7707bf3908603927b73d6c4c200818a6693\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T13:44:36+08:00\"}],\"CompareURL\":\"\"}',1572932755),(11,2,16,1,'chenms',3,'butterfly','cache','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"62ecd7707bf3908603927b73d6c4c200818a6693\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T13:44:36+08:00\"}],\"CompareURL\":\"\"}',1572932755),(12,1,5,1,'chenms',3,'butterfly','cache','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"62ecd7707bf3908603927b73d6c4c200818a6693\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T13:44:36+08:00\"}],\"CompareURL\":\"\"}',1572932755),(13,2,5,1,'chenms',3,'butterfly','cache','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"62ecd7707bf3908603927b73d6c4c200818a6693\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2019-11-05T13:44:36+08:00\"}],\"CompareURL\":\"\"}',1572932755),(14,1,1,1,'chenms',4,'butterfly','config','',0,'',1572933449),(15,2,1,1,'chenms',4,'butterfly','config','',0,'',1572933449),(16,1,16,1,'chenms',4,'butterfly','config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9eaa7698d63074585684520ff6d3efcac8957094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T13:56:43+08:00\"}],\"CompareURL\":\"\"}',1572933477),(17,2,16,1,'chenms',4,'butterfly','config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9eaa7698d63074585684520ff6d3efcac8957094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T13:56:43+08:00\"}],\"CompareURL\":\"\"}',1572933477),(18,1,5,1,'chenms',4,'butterfly','config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9eaa7698d63074585684520ff6d3efcac8957094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T13:56:43+08:00\"}],\"CompareURL\":\"\"}',1572933477),(19,2,5,1,'chenms',4,'butterfly','config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9eaa7698d63074585684520ff6d3efcac8957094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T13:56:43+08:00\"}],\"CompareURL\":\"\"}',1572933478),(20,1,1,1,'chenms',5,'butterfly','console','',0,'',1572934163),(21,2,1,1,'chenms',5,'butterfly','console','',0,'',1572934163),(22,1,16,1,'chenms',5,'butterfly','console','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"65afd4a5fb80ac689c5904ab20aa1076750f86d3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:09:00+08:00\"}],\"CompareURL\":\"\"}',1572934201),(23,2,16,1,'chenms',5,'butterfly','console','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"65afd4a5fb80ac689c5904ab20aa1076750f86d3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:09:00+08:00\"}],\"CompareURL\":\"\"}',1572934201),(24,1,5,1,'chenms',5,'butterfly','console','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"65afd4a5fb80ac689c5904ab20aa1076750f86d3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:09:00+08:00\"}],\"CompareURL\":\"\"}',1572934201),(25,2,5,1,'chenms',5,'butterfly','console','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"65afd4a5fb80ac689c5904ab20aa1076750f86d3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:09:00+08:00\"}],\"CompareURL\":\"\"}',1572934202),(26,1,1,1,'chenms',6,'butterfly','container','',0,'',1572934588),(27,2,1,1,'chenms',6,'butterfly','container','',0,'',1572934588),(28,1,16,1,'chenms',6,'butterfly','container','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"029a186a9c9ddecbba70f8be37f3c3edc620603b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:16:57+08:00\"}],\"CompareURL\":\"\"}',1572934638),(29,2,16,1,'chenms',6,'butterfly','container','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"029a186a9c9ddecbba70f8be37f3c3edc620603b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:16:57+08:00\"}],\"CompareURL\":\"\"}',1572934638),(30,1,5,1,'chenms',6,'butterfly','container','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"029a186a9c9ddecbba70f8be37f3c3edc620603b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:16:57+08:00\"}],\"CompareURL\":\"\"}',1572934638),(31,2,5,1,'chenms',6,'butterfly','container','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"029a186a9c9ddecbba70f8be37f3c3edc620603b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:16:57+08:00\"}],\"CompareURL\":\"\"}',1572934638),(32,1,1,1,'chenms',7,'butterfly','database','',0,'',1572935246),(33,2,1,1,'chenms',7,'butterfly','database','',0,'',1572935246),(34,1,16,1,'chenms',7,'butterfly','database','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8e9b0662c6459955f8a925230ba166e5aba27d5a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:26:59+08:00\"}],\"CompareURL\":\"\"}',1572935267),(35,2,16,1,'chenms',7,'butterfly','database','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8e9b0662c6459955f8a925230ba166e5aba27d5a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:26:59+08:00\"}],\"CompareURL\":\"\"}',1572935267),(36,1,5,1,'chenms',7,'butterfly','database','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8e9b0662c6459955f8a925230ba166e5aba27d5a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:26:59+08:00\"}],\"CompareURL\":\"\"}',1572935267),(37,2,5,1,'chenms',7,'butterfly','database','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8e9b0662c6459955f8a925230ba166e5aba27d5a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:26:59+08:00\"}],\"CompareURL\":\"\"}',1572935267),(38,1,1,1,'chenms',8,'butterfly','encryption','',0,'',1572935497),(39,2,1,1,'chenms',8,'butterfly','encryption','',0,'',1572935497),(40,1,16,1,'chenms',8,'butterfly','encryption','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"74b6bba9be5f7dcf5e96e4b674f44870aebced83\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:31:51+08:00\"}],\"CompareURL\":\"\"}',1572935649),(41,2,16,1,'chenms',8,'butterfly','encryption','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"74b6bba9be5f7dcf5e96e4b674f44870aebced83\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:31:51+08:00\"}],\"CompareURL\":\"\"}',1572935649),(42,1,5,1,'chenms',8,'butterfly','encryption','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"74b6bba9be5f7dcf5e96e4b674f44870aebced83\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:31:51+08:00\"}],\"CompareURL\":\"\"}',1572935649),(43,2,5,1,'chenms',8,'butterfly','encryption','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"74b6bba9be5f7dcf5e96e4b674f44870aebced83\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:31:51+08:00\"}],\"CompareURL\":\"\"}',1572935649),(44,1,1,1,'chenms',9,'butterfly','error','',0,'',1572935693),(45,2,1,1,'chenms',9,'butterfly','error','',0,'',1572935693),(46,1,16,1,'chenms',9,'butterfly','error','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"79f3ac43a8dea5bd1296b37d4a70393fdabe2fd3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:34:42+08:00\"}],\"CompareURL\":\"\"}',1572935710),(47,2,16,1,'chenms',9,'butterfly','error','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"79f3ac43a8dea5bd1296b37d4a70393fdabe2fd3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:34:42+08:00\"}],\"CompareURL\":\"\"}',1572935710),(48,1,5,1,'chenms',9,'butterfly','error','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"79f3ac43a8dea5bd1296b37d4a70393fdabe2fd3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:34:42+08:00\"}],\"CompareURL\":\"\"}',1572935710),(49,2,5,1,'chenms',9,'butterfly','error','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"79f3ac43a8dea5bd1296b37d4a70393fdabe2fd3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:34:42+08:00\"}],\"CompareURL\":\"\"}',1572935710),(50,1,1,1,'chenms',10,'butterfly','foundation','',0,'',1572935763),(51,2,1,1,'chenms',10,'butterfly','foundation','',0,'',1572935763),(52,1,16,1,'chenms',10,'butterfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ba8bcbd57fc957e40f1f20735a694ebaaa71ac3e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:35:36+08:00\"}],\"CompareURL\":\"\"}',1572935782),(53,2,16,1,'chenms',10,'butterfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ba8bcbd57fc957e40f1f20735a694ebaaa71ac3e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:35:36+08:00\"}],\"CompareURL\":\"\"}',1572935782),(54,1,5,1,'chenms',10,'butterfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ba8bcbd57fc957e40f1f20735a694ebaaa71ac3e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:35:36+08:00\"}],\"CompareURL\":\"\"}',1572935782),(55,2,5,1,'chenms',10,'butterfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ba8bcbd57fc957e40f1f20735a694ebaaa71ac3e\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:35:36+08:00\"}],\"CompareURL\":\"\"}',1572935782),(56,1,1,1,'chenms',11,'butterfly','http','',0,'',1572935869),(57,2,1,1,'chenms',11,'butterfly','http','',0,'',1572935869),(58,1,16,1,'chenms',11,'butterfly','http','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"444bad365f223eba993f26360b94b1a580aaf3b3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:37:36+08:00\"}],\"CompareURL\":\"\"}',1572935883),(59,2,16,1,'chenms',11,'butterfly','http','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"444bad365f223eba993f26360b94b1a580aaf3b3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:37:36+08:00\"}],\"CompareURL\":\"\"}',1572935883),(60,1,5,1,'chenms',11,'butterfly','http','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"444bad365f223eba993f26360b94b1a580aaf3b3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:37:36+08:00\"}],\"CompareURL\":\"\"}',1572935883),(61,2,5,1,'chenms',11,'butterfly','http','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"444bad365f223eba993f26360b94b1a580aaf3b3\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:37:36+08:00\"}],\"CompareURL\":\"\"}',1572935883),(62,1,1,1,'chenms',12,'butterfly','ip-location','',0,'',1572935925),(63,2,1,1,'chenms',12,'butterfly','ip-location','',0,'',1572935925),(64,1,16,1,'chenms',12,'butterfly','ip-location','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"994a2b63aa6f85b5dc813623edbeed2b1c6d199a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:38:29+08:00\"}],\"CompareURL\":\"\"}',1572935945),(65,2,16,1,'chenms',12,'butterfly','ip-location','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"994a2b63aa6f85b5dc813623edbeed2b1c6d199a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:38:29+08:00\"}],\"CompareURL\":\"\"}',1572935945),(66,1,5,1,'chenms',12,'butterfly','ip-location','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"994a2b63aa6f85b5dc813623edbeed2b1c6d199a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:38:29+08:00\"}],\"CompareURL\":\"\"}',1572935945),(67,2,5,1,'chenms',12,'butterfly','ip-location','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"994a2b63aa6f85b5dc813623edbeed2b1c6d199a\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:38:29+08:00\"}],\"CompareURL\":\"\"}',1572935945),(68,1,1,1,'chenms',13,'butterfly','log','',0,'',1572935978),(69,2,1,1,'chenms',13,'butterfly','log','',0,'',1572935978),(70,1,16,1,'chenms',13,'butterfly','log','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5b3b45d40df6a5069ecbac37b2472a636cafba55\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:39:25+08:00\"}],\"CompareURL\":\"\"}',1572935989),(71,2,16,1,'chenms',13,'butterfly','log','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5b3b45d40df6a5069ecbac37b2472a636cafba55\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:39:25+08:00\"}],\"CompareURL\":\"\"}',1572935989),(72,1,5,1,'chenms',13,'butterfly','log','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5b3b45d40df6a5069ecbac37b2472a636cafba55\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:39:25+08:00\"}],\"CompareURL\":\"\"}',1572935989),(73,2,5,1,'chenms',13,'butterfly','log','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5b3b45d40df6a5069ecbac37b2472a636cafba55\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:39:25+08:00\"}],\"CompareURL\":\"\"}',1572935989),(74,1,1,1,'chenms',14,'butterfly','mail','',0,'',1572936055),(75,2,1,1,'chenms',14,'butterfly','mail','',0,'',1572936055),(76,1,16,1,'chenms',14,'butterfly','mail','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4bc71d9df3dd32771505ada5e5be18b4b546b2cd\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:40:42+08:00\"}],\"CompareURL\":\"\"}',1572936071),(77,2,16,1,'chenms',14,'butterfly','mail','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4bc71d9df3dd32771505ada5e5be18b4b546b2cd\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:40:42+08:00\"}],\"CompareURL\":\"\"}',1572936071),(78,1,5,1,'chenms',14,'butterfly','mail','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4bc71d9df3dd32771505ada5e5be18b4b546b2cd\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:40:42+08:00\"}],\"CompareURL\":\"\"}',1572936071),(79,2,5,1,'chenms',14,'butterfly','mail','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4bc71d9df3dd32771505ada5e5be18b4b546b2cd\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:40:42+08:00\"}],\"CompareURL\":\"\"}',1572936071),(80,1,1,1,'chenms',15,'butterfly','pagination','',0,'',1572936189),(81,2,1,1,'chenms',15,'butterfly','pagination','',0,'',1572936189),(82,1,16,1,'chenms',15,'butterfly','pagination','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"11e97c80540d12341f0db9b72751c93a5a1cff28\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:42:46+08:00\"}],\"CompareURL\":\"\"}',1572936210),(83,2,16,1,'chenms',15,'butterfly','pagination','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"11e97c80540d12341f0db9b72751c93a5a1cff28\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:42:46+08:00\"}],\"CompareURL\":\"\"}',1572936210),(84,1,5,1,'chenms',15,'butterfly','pagination','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"11e97c80540d12341f0db9b72751c93a5a1cff28\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:42:46+08:00\"}],\"CompareURL\":\"\"}',1572936210),(85,2,5,1,'chenms',15,'butterfly','pagination','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"11e97c80540d12341f0db9b72751c93a5a1cff28\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:42:46+08:00\"}],\"CompareURL\":\"\"}',1572936210),(86,1,1,1,'chenms',16,'butterfly','provider-basic','',0,'',1572936266),(87,2,1,1,'chenms',16,'butterfly','provider-basic','',0,'',1572936266),(88,1,16,1,'chenms',16,'butterfly','provider-basic','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f35ff5626e0c7224d56358b3aec025e8e2155117\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:43:57+08:00\"}],\"CompareURL\":\"\"}',1572936285),(89,2,16,1,'chenms',16,'butterfly','provider-basic','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f35ff5626e0c7224d56358b3aec025e8e2155117\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:43:57+08:00\"}],\"CompareURL\":\"\"}',1572936285),(90,1,5,1,'chenms',16,'butterfly','provider-basic','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f35ff5626e0c7224d56358b3aec025e8e2155117\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:43:57+08:00\"}],\"CompareURL\":\"\"}',1572936285),(91,2,5,1,'chenms',16,'butterfly','provider-basic','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f35ff5626e0c7224d56358b3aec025e8e2155117\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:43:57+08:00\"}],\"CompareURL\":\"\"}',1572936285),(92,1,1,1,'chenms',17,'butterfly','provider-core','',0,'',1572936334),(93,2,1,1,'chenms',17,'butterfly','provider-core','',0,'',1572936334),(94,1,16,1,'chenms',17,'butterfly','provider-core','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f6704850c1c112c7e235d0ea34ad4ee0843ca7a6\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:45:10+08:00\"}],\"CompareURL\":\"\"}',1572936338),(95,2,16,1,'chenms',17,'butterfly','provider-core','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f6704850c1c112c7e235d0ea34ad4ee0843ca7a6\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:45:10+08:00\"}],\"CompareURL\":\"\"}',1572936338),(96,1,5,1,'chenms',17,'butterfly','provider-core','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f6704850c1c112c7e235d0ea34ad4ee0843ca7a6\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:45:10+08:00\"}],\"CompareURL\":\"\"}',1572936338),(97,2,5,1,'chenms',17,'butterfly','provider-core','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f6704850c1c112c7e235d0ea34ad4ee0843ca7a6\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:45:10+08:00\"}],\"CompareURL\":\"\"}',1572936338),(98,1,1,1,'chenms',18,'butterfly','provider-db','',0,'',1572936414),(99,2,1,1,'chenms',18,'butterfly','provider-db','',0,'',1572936414),(100,1,16,1,'chenms',18,'butterfly','provider-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"fa2d9e6d6b416d9e90a2e9bda37cbfdbb6a648db\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:46:31+08:00\"}],\"CompareURL\":\"\"}',1572936438),(101,2,16,1,'chenms',18,'butterfly','provider-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"fa2d9e6d6b416d9e90a2e9bda37cbfdbb6a648db\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:46:31+08:00\"}],\"CompareURL\":\"\"}',1572936438),(102,1,5,1,'chenms',18,'butterfly','provider-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"fa2d9e6d6b416d9e90a2e9bda37cbfdbb6a648db\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:46:31+08:00\"}],\"CompareURL\":\"\"}',1572936438),(103,2,5,1,'chenms',18,'butterfly','provider-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"fa2d9e6d6b416d9e90a2e9bda37cbfdbb6a648db\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:46:31+08:00\"}],\"CompareURL\":\"\"}',1572936438),(104,1,1,1,'chenms',19,'butterfly','provider-rest','',0,'',1572936499),(105,2,1,1,'chenms',19,'butterfly','provider-rest','',0,'',1572936499),(106,1,16,1,'chenms',19,'butterfly','provider-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b3f42fd0980710d547f71d21c6883ead89788094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:01+08:00\"}],\"CompareURL\":\"\"}',1572936503),(107,2,16,1,'chenms',19,'butterfly','provider-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b3f42fd0980710d547f71d21c6883ead89788094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:01+08:00\"}],\"CompareURL\":\"\"}',1572936503),(108,1,5,1,'chenms',19,'butterfly','provider-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b3f42fd0980710d547f71d21c6883ead89788094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:01+08:00\"}],\"CompareURL\":\"\"}',1572936503),(109,2,5,1,'chenms',19,'butterfly','provider-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b3f42fd0980710d547f71d21c6883ead89788094\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:01+08:00\"}],\"CompareURL\":\"\"}',1572936503),(110,1,1,1,'chenms',20,'butterfly','provider-web','',0,'',1572936560),(111,2,1,1,'chenms',20,'butterfly','provider-web','',0,'',1572936560),(112,1,16,1,'chenms',20,'butterfly','provider-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9b200ba8a46deedf960fb6fc2b97331b3c1a36ab\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:57+08:00\"}],\"CompareURL\":\"\"}',1572936565),(113,2,16,1,'chenms',20,'butterfly','provider-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9b200ba8a46deedf960fb6fc2b97331b3c1a36ab\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:57+08:00\"}],\"CompareURL\":\"\"}',1572936565),(114,1,5,1,'chenms',20,'butterfly','provider-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9b200ba8a46deedf960fb6fc2b97331b3c1a36ab\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:57+08:00\"}],\"CompareURL\":\"\"}',1572936565),(115,2,5,1,'chenms',20,'butterfly','provider-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9b200ba8a46deedf960fb6fc2b97331b3c1a36ab\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:48:57+08:00\"}],\"CompareURL\":\"\"}',1572936565),(116,1,1,1,'chenms',21,'butterfly','rest','',0,'',1572936647),(117,2,1,1,'chenms',21,'butterfly','rest','',0,'',1572936647),(118,1,16,1,'chenms',21,'butterfly','rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"977b0d6cc85d004d194382a1941aa96049672e3d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:50:23+08:00\"}],\"CompareURL\":\"\"}',1572936650),(119,2,16,1,'chenms',21,'butterfly','rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"977b0d6cc85d004d194382a1941aa96049672e3d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:50:23+08:00\"}],\"CompareURL\":\"\"}',1572936650),(120,1,5,1,'chenms',21,'butterfly','rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"977b0d6cc85d004d194382a1941aa96049672e3d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:50:23+08:00\"}],\"CompareURL\":\"\"}',1572936650),(121,2,5,1,'chenms',21,'butterfly','rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"977b0d6cc85d004d194382a1941aa96049672e3d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:50:23+08:00\"}],\"CompareURL\":\"\"}',1572936650),(122,1,1,1,'chenms',22,'butterfly','statical','',0,'',1572936687),(123,2,1,1,'chenms',22,'butterfly','statical','',0,'',1572936687),(124,1,16,1,'chenms',22,'butterfly','statical','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e411138514dcc7850b6875147afb1023e56cc69f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:06+08:00\"}],\"CompareURL\":\"\"}',1572936691),(125,2,16,1,'chenms',22,'butterfly','statical','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e411138514dcc7850b6875147afb1023e56cc69f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:06+08:00\"}],\"CompareURL\":\"\"}',1572936691),(126,1,5,1,'chenms',22,'butterfly','statical','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e411138514dcc7850b6875147afb1023e56cc69f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:06+08:00\"}],\"CompareURL\":\"\"}',1572936691),(127,2,5,1,'chenms',22,'butterfly','statical','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e411138514dcc7850b6875147afb1023e56cc69f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:06+08:00\"}],\"CompareURL\":\"\"}',1572936691),(128,1,1,1,'chenms',23,'butterfly','utility','',0,'',1572936745),(129,2,1,1,'chenms',23,'butterfly','utility','',0,'',1572936745),(130,1,16,1,'chenms',23,'butterfly','utility','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9e2a72ff0d0aa226915c2aafeca54c9daf4f48c5\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:52+08:00\"}],\"CompareURL\":\"\"}',1572936749),(131,2,16,1,'chenms',23,'butterfly','utility','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9e2a72ff0d0aa226915c2aafeca54c9daf4f48c5\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:52+08:00\"}],\"CompareURL\":\"\"}',1572936749),(132,1,5,1,'chenms',23,'butterfly','utility','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9e2a72ff0d0aa226915c2aafeca54c9daf4f48c5\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:52+08:00\"}],\"CompareURL\":\"\"}',1572936749),(133,2,5,1,'chenms',23,'butterfly','utility','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9e2a72ff0d0aa226915c2aafeca54c9daf4f48c5\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:51:52+08:00\"}],\"CompareURL\":\"\"}',1572936749),(134,1,1,1,'chenms',24,'butterfly','validator','',0,'',1572937138),(135,2,1,1,'chenms',24,'butterfly','validator','',0,'',1572937138),(136,1,16,1,'chenms',24,'butterfly','validator','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f57b0cea7a2fa7666c1f6681205270c5348d1c36\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:58:29+08:00\"}],\"CompareURL\":\"\"}',1572937142),(137,2,16,1,'chenms',24,'butterfly','validator','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f57b0cea7a2fa7666c1f6681205270c5348d1c36\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:58:29+08:00\"}],\"CompareURL\":\"\"}',1572937143),(138,1,5,1,'chenms',24,'butterfly','validator','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f57b0cea7a2fa7666c1f6681205270c5348d1c36\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:58:29+08:00\"}],\"CompareURL\":\"\"}',1572937143),(139,2,5,1,'chenms',24,'butterfly','validator','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f57b0cea7a2fa7666c1f6681205270c5348d1c36\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:58:29+08:00\"}],\"CompareURL\":\"\"}',1572937143),(140,1,1,1,'chenms',25,'butterfly','view','',0,'',1572937180),(141,2,1,1,'chenms',25,'butterfly','view','',0,'',1572937180),(142,1,16,1,'chenms',25,'butterfly','view','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"88f755d04de4e945b20c1e3ed87c79ad604e948c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:59:21+08:00\"}],\"CompareURL\":\"\"}',1572937183),(143,2,16,1,'chenms',25,'butterfly','view','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"88f755d04de4e945b20c1e3ed87c79ad604e948c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:59:21+08:00\"}],\"CompareURL\":\"\"}',1572937183),(144,1,5,1,'chenms',25,'butterfly','view','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"88f755d04de4e945b20c1e3ed87c79ad604e948c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:59:21+08:00\"}],\"CompareURL\":\"\"}',1572937183),(145,2,5,1,'chenms',25,'butterfly','view','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"88f755d04de4e945b20c1e3ed87c79ad604e948c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T14:59:21+08:00\"}],\"CompareURL\":\"\"}',1572937183),(146,1,1,1,'chenms',26,'butterfly','web','',0,'',1572937284),(147,2,1,1,'chenms',26,'butterfly','web','',0,'',1572937284),(148,1,16,1,'chenms',26,'butterfly','web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2d9a9e0ec41da61b28536836bd44aa6d7514076c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:01:07+08:00\"}],\"CompareURL\":\"\"}',1572937287),(149,2,16,1,'chenms',26,'butterfly','web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2d9a9e0ec41da61b28536836bd44aa6d7514076c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:01:07+08:00\"}],\"CompareURL\":\"\"}',1572937287),(150,1,5,1,'chenms',26,'butterfly','web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2d9a9e0ec41da61b28536836bd44aa6d7514076c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:01:07+08:00\"}],\"CompareURL\":\"\"}',1572937287),(151,2,5,1,'chenms',26,'butterfly','web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2d9a9e0ec41da61b28536836bd44aa6d7514076c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:01:07+08:00\"}],\"CompareURL\":\"\"}',1572937287),(152,1,1,1,'chenms',27,'firefly','alias-auto-complete','',0,'',1572937636),(153,3,1,1,'chenms',27,'firefly','alias-auto-complete','',0,'',1572937636),(154,1,16,1,'chenms',27,'firefly','alias-auto-complete','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"428104d0e02bee90737408e2ed247eaa1a999f21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:06:55+08:00\"},{\"Sha1\":\"68eab23517d199b871a22f0c9c0ff6ba140c5ca4\",\"Message\":\"Firefly框架中用到的类的别名的自动完成支持\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T14:33:17+08:00\"}],\"CompareURL\":\"\"}',1572937704),(155,3,16,1,'chenms',27,'firefly','alias-auto-complete','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"428104d0e02bee90737408e2ed247eaa1a999f21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:06:55+08:00\"},{\"Sha1\":\"68eab23517d199b871a22f0c9c0ff6ba140c5ca4\",\"Message\":\"Firefly框架中用到的类的别名的自动完成支持\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T14:33:17+08:00\"}],\"CompareURL\":\"\"}',1572937704),(156,1,5,1,'chenms',27,'firefly','alias-auto-complete','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"428104d0e02bee90737408e2ed247eaa1a999f21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:06:55+08:00\"},{\"Sha1\":\"68eab23517d199b871a22f0c9c0ff6ba140c5ca4\",\"Message\":\"Firefly框架中用到的类的别名的自动完成支持\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T14:33:17+08:00\"}],\"CompareURL\":\"\"}',1572937704),(157,3,5,1,'chenms',27,'firefly','alias-auto-complete','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"428104d0e02bee90737408e2ed247eaa1a999f21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:06:55+08:00\"},{\"Sha1\":\"68eab23517d199b871a22f0c9c0ff6ba140c5ca4\",\"Message\":\"Firefly框架中用到的类的别名的自动完成支持\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T14:33:17+08:00\"}],\"CompareURL\":\"\"}',1572937704),(158,1,1,1,'chenms',28,'firefly','framework','',0,'',1572937863),(159,3,1,1,'chenms',28,'firefly','framework','',0,'',1572937863),(160,1,16,1,'chenms',28,'firefly','framework','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"7af189a50b54ac34895eade032fdb3522a14e9c4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:09:31+08:00\"},{\"Sha1\":\"1e45fc7c2b31b10eb7be10d2056831ced8630d8d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T15:24:42+08:00\"}],\"CompareURL\":\"\"}',1572937867),(161,3,16,1,'chenms',28,'firefly','framework','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"7af189a50b54ac34895eade032fdb3522a14e9c4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:09:31+08:00\"},{\"Sha1\":\"1e45fc7c2b31b10eb7be10d2056831ced8630d8d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T15:24:42+08:00\"}],\"CompareURL\":\"\"}',1572937867),(162,1,5,1,'chenms',28,'firefly','framework','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"7af189a50b54ac34895eade032fdb3522a14e9c4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:09:31+08:00\"},{\"Sha1\":\"1e45fc7c2b31b10eb7be10d2056831ced8630d8d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T15:24:42+08:00\"}],\"CompareURL\":\"\"}',1572937867),(163,3,5,1,'chenms',28,'firefly','framework','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"7af189a50b54ac34895eade032fdb3522a14e9c4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:09:31+08:00\"},{\"Sha1\":\"1e45fc7c2b31b10eb7be10d2056831ced8630d8d\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"ameiurl\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"ameiurl\",\"Timestamp\":\"2017-04-25T15:24:42+08:00\"}],\"CompareURL\":\"\"}',1572937867),(164,1,1,1,'chenms',29,'firefly','project-cli','',0,'',1572937981),(165,3,1,1,'chenms',29,'firefly','project-cli','',0,'',1572937981),(166,1,16,1,'chenms',29,'firefly','project-cli','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"db6be9133c204f8551cca628cc503d79c8d8f8fa\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:12:34+08:00\"}],\"CompareURL\":\"\"}',1572937985),(167,3,16,1,'chenms',29,'firefly','project-cli','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"db6be9133c204f8551cca628cc503d79c8d8f8fa\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:12:34+08:00\"}],\"CompareURL\":\"\"}',1572937985),(168,1,5,1,'chenms',29,'firefly','project-cli','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"db6be9133c204f8551cca628cc503d79c8d8f8fa\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:12:34+08:00\"}],\"CompareURL\":\"\"}',1572937985),(169,3,5,1,'chenms',29,'firefly','project-cli','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"db6be9133c204f8551cca628cc503d79c8d8f8fa\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:12:34+08:00\"}],\"CompareURL\":\"\"}',1572937985),(170,1,1,1,'chenms',30,'firefly','project-db','',0,'',1572938033),(171,3,1,1,'chenms',30,'firefly','project-db','',0,'',1572938033),(172,1,16,1,'chenms',30,'firefly','project-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c4db7764528d907827bd87be62d36ec30d5786b7\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:13:29+08:00\"}],\"CompareURL\":\"\"}',1572938038),(173,3,16,1,'chenms',30,'firefly','project-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c4db7764528d907827bd87be62d36ec30d5786b7\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:13:29+08:00\"}],\"CompareURL\":\"\"}',1572938038),(174,1,5,1,'chenms',30,'firefly','project-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c4db7764528d907827bd87be62d36ec30d5786b7\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:13:29+08:00\"}],\"CompareURL\":\"\"}',1572938038),(175,3,5,1,'chenms',30,'firefly','project-db','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c4db7764528d907827bd87be62d36ec30d5786b7\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:13:29+08:00\"}],\"CompareURL\":\"\"}',1572938038),(176,1,1,1,'chenms',31,'firefly','project-mweb','',0,'',1572938091),(177,3,1,1,'chenms',31,'firefly','project-mweb','',0,'',1572938091),(178,1,16,1,'chenms',31,'firefly','project-mweb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"50ff0ad133b47967c425e6f06dde9c9b6cbcb4d9\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:14:23+08:00\"}],\"CompareURL\":\"\"}',1572938095),(179,3,16,1,'chenms',31,'firefly','project-mweb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"50ff0ad133b47967c425e6f06dde9c9b6cbcb4d9\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:14:23+08:00\"}],\"CompareURL\":\"\"}',1572938095),(180,1,5,1,'chenms',31,'firefly','project-mweb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"50ff0ad133b47967c425e6f06dde9c9b6cbcb4d9\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:14:23+08:00\"}],\"CompareURL\":\"\"}',1572938095),(181,3,5,1,'chenms',31,'firefly','project-mweb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"50ff0ad133b47967c425e6f06dde9c9b6cbcb4d9\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:14:23+08:00\"}],\"CompareURL\":\"\"}',1572938095),(182,1,1,1,'chenms',32,'firefly','project-rest','',0,'',1572938145),(183,3,1,1,'chenms',32,'firefly','project-rest','',0,'',1572938145),(184,1,16,1,'chenms',32,'firefly','project-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"91f70866590041154fd27a30eb2edeba956b59e1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:15:18+08:00\"}],\"CompareURL\":\"\"}',1572938149),(185,3,16,1,'chenms',32,'firefly','project-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"91f70866590041154fd27a30eb2edeba956b59e1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:15:18+08:00\"}],\"CompareURL\":\"\"}',1572938149),(186,1,5,1,'chenms',32,'firefly','project-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"91f70866590041154fd27a30eb2edeba956b59e1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:15:18+08:00\"}],\"CompareURL\":\"\"}',1572938149),(187,3,5,1,'chenms',32,'firefly','project-rest','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"91f70866590041154fd27a30eb2edeba956b59e1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:15:18+08:00\"}],\"CompareURL\":\"\"}',1572938149),(188,1,1,1,'chenms',33,'firefly','project-web','',0,'',1572938198),(189,3,1,1,'chenms',33,'firefly','project-web','',0,'',1572938198),(190,1,16,1,'chenms',33,'firefly','project-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"76482b14857b9d6f807e92fdfcbb46b053fd0d62\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:16:20+08:00\"}],\"CompareURL\":\"\"}',1572938202),(191,3,16,1,'chenms',33,'firefly','project-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"76482b14857b9d6f807e92fdfcbb46b053fd0d62\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:16:20+08:00\"}],\"CompareURL\":\"\"}',1572938202),(192,1,5,1,'chenms',33,'firefly','project-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"76482b14857b9d6f807e92fdfcbb46b053fd0d62\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:16:20+08:00\"}],\"CompareURL\":\"\"}',1572938202),(193,3,5,1,'chenms',33,'firefly','project-web','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"76482b14857b9d6f807e92fdfcbb46b053fd0d62\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:16:20+08:00\"}],\"CompareURL\":\"\"}',1572938202),(194,1,1,1,'chenms',34,'firefly','satis-config','',0,'',1572938247),(195,3,1,1,'chenms',34,'firefly','satis-config','',0,'',1572938247),(196,1,16,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"7f7a6162a8c7dbb7e914a441b76c00bee7bdd275\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:01+08:00\"}],\"CompareURL\":\"\"}',1572938251),(197,3,16,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"7f7a6162a8c7dbb7e914a441b76c00bee7bdd275\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:01+08:00\"}],\"CompareURL\":\"\"}',1572938251),(198,1,5,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"7f7a6162a8c7dbb7e914a441b76c00bee7bdd275\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:01+08:00\"}],\"CompareURL\":\"\"}',1572938251),(199,3,5,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"7f7a6162a8c7dbb7e914a441b76c00bee7bdd275\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:01+08:00\"}],\"CompareURL\":\"\"}',1572938251),(200,1,1,1,'chenms',35,'firefly','skeleton','',0,'',1572938312),(201,3,1,1,'chenms',35,'firefly','skeleton','',0,'',1572938312),(202,1,16,1,'chenms',35,'firefly','skeleton','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2ea3691efc6e471e059ef3a9a479af2dcd8ed79f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:58+08:00\"}],\"CompareURL\":\"\"}',1572938317),(203,3,16,1,'chenms',35,'firefly','skeleton','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2ea3691efc6e471e059ef3a9a479af2dcd8ed79f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:58+08:00\"}],\"CompareURL\":\"\"}',1572938317),(204,1,5,1,'chenms',35,'firefly','skeleton','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2ea3691efc6e471e059ef3a9a479af2dcd8ed79f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:58+08:00\"}],\"CompareURL\":\"\"}',1572938317),(205,3,5,1,'chenms',35,'firefly','skeleton','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2ea3691efc6e471e059ef3a9a479af2dcd8ed79f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T15:17:58+08:00\"}],\"CompareURL\":\"\"}',1572938317),(206,1,1,1,'chenms',36,'dragonfly','browser','',0,'',1572945369),(207,4,1,1,'chenms',36,'dragonfly','browser','',0,'',1572945369),(208,1,16,1,'chenms',36,'dragonfly','browser','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8a01cb7923080e15554df93fdef324b476a43ff4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:10:28+08:00\"}],\"CompareURL\":\"\"}',1572945393),(209,4,16,1,'chenms',36,'dragonfly','browser','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8a01cb7923080e15554df93fdef324b476a43ff4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:10:28+08:00\"}],\"CompareURL\":\"\"}',1572945393),(210,1,5,1,'chenms',36,'dragonfly','browser','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8a01cb7923080e15554df93fdef324b476a43ff4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:10:28+08:00\"}],\"CompareURL\":\"\"}',1572945393),(211,4,5,1,'chenms',36,'dragonfly','browser','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8a01cb7923080e15554df93fdef324b476a43ff4\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:10:28+08:00\"}],\"CompareURL\":\"\"}',1572945393),(212,1,1,1,'chenms',37,'dragonfly','company','',0,'',1572945433),(213,4,1,1,'chenms',37,'dragonfly','company','',0,'',1572945433),(214,1,16,1,'chenms',37,'dragonfly','company','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"426f724e1f64ae9f73733d602df0327a62af383f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:16:59+08:00\"}],\"CompareURL\":\"\"}',1572945448),(215,4,16,1,'chenms',37,'dragonfly','company','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"426f724e1f64ae9f73733d602df0327a62af383f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:16:59+08:00\"}],\"CompareURL\":\"\"}',1572945448),(216,1,5,1,'chenms',37,'dragonfly','company','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"426f724e1f64ae9f73733d602df0327a62af383f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:16:59+08:00\"}],\"CompareURL\":\"\"}',1572945448),(217,4,5,1,'chenms',37,'dragonfly','company','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"426f724e1f64ae9f73733d602df0327a62af383f\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:16:59+08:00\"}],\"CompareURL\":\"\"}',1572945448),(218,1,1,1,'chenms',38,'dragonfly','ip','',0,'',1572945493),(219,4,1,1,'chenms',38,'dragonfly','ip','',0,'',1572945493),(220,1,16,1,'chenms',38,'dragonfly','ip','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"85b93a41a3efc24a1620793bb068172e3c780d75\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:17:50+08:00\"}],\"CompareURL\":\"\"}',1572945499),(221,4,16,1,'chenms',38,'dragonfly','ip','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"85b93a41a3efc24a1620793bb068172e3c780d75\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:17:50+08:00\"}],\"CompareURL\":\"\"}',1572945499),(222,1,5,1,'chenms',38,'dragonfly','ip','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"85b93a41a3efc24a1620793bb068172e3c780d75\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:17:50+08:00\"}],\"CompareURL\":\"\"}',1572945499),(223,4,5,1,'chenms',38,'dragonfly','ip','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"85b93a41a3efc24a1620793bb068172e3c780d75\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:17:50+08:00\"}],\"CompareURL\":\"\"}',1572945499),(224,1,1,1,'chenms',39,'dragonfly','rpc','',0,'',1572945543),(225,4,1,1,'chenms',39,'dragonfly','rpc','',0,'',1572945543),(226,1,16,1,'chenms',39,'dragonfly','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"54966326c09281d5f842fc215df6d2fdefd75060\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:18:44+08:00\"}],\"CompareURL\":\"\"}',1572945557),(227,4,16,1,'chenms',39,'dragonfly','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"54966326c09281d5f842fc215df6d2fdefd75060\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:18:44+08:00\"}],\"CompareURL\":\"\"}',1572945557),(228,1,5,1,'chenms',39,'dragonfly','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"54966326c09281d5f842fc215df6d2fdefd75060\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:18:44+08:00\"}],\"CompareURL\":\"\"}',1572945557),(229,4,5,1,'chenms',39,'dragonfly','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"54966326c09281d5f842fc215df6d2fdefd75060\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:18:44+08:00\"}],\"CompareURL\":\"\"}',1572945557),(230,1,1,1,'chenms',40,'dragonfly','session','',0,'',1572945602),(231,4,1,1,'chenms',40,'dragonfly','session','',0,'',1572945602),(232,1,16,1,'chenms',40,'dragonfly','session','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"56f7a46230cff46b1f21486b9861f1610d4d0ced\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:19:37+08:00\"}],\"CompareURL\":\"\"}',1572945607),(233,4,16,1,'chenms',40,'dragonfly','session','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"56f7a46230cff46b1f21486b9861f1610d4d0ced\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:19:37+08:00\"}],\"CompareURL\":\"\"}',1572945607),(234,1,5,1,'chenms',40,'dragonfly','session','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"56f7a46230cff46b1f21486b9861f1610d4d0ced\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:19:37+08:00\"}],\"CompareURL\":\"\"}',1572945607),(235,4,5,1,'chenms',40,'dragonfly','session','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"56f7a46230cff46b1f21486b9861f1610d4d0ced\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:19:37+08:00\"}],\"CompareURL\":\"\"}',1572945607),(236,1,1,1,'chenms',41,'dragonfly','ubb','',0,'',1572945641),(237,4,1,1,'chenms',41,'dragonfly','ubb','',0,'',1572945641),(238,1,16,1,'chenms',41,'dragonfly','ubb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8f27e51d582a50bac460cd4bf8d581e4beed7b21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:20:22+08:00\"}],\"CompareURL\":\"\"}',1572945644),(239,4,16,1,'chenms',41,'dragonfly','ubb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8f27e51d582a50bac460cd4bf8d581e4beed7b21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:20:22+08:00\"}],\"CompareURL\":\"\"}',1572945644),(240,1,5,1,'chenms',41,'dragonfly','ubb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8f27e51d582a50bac460cd4bf8d581e4beed7b21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:20:22+08:00\"}],\"CompareURL\":\"\"}',1572945644),(241,4,5,1,'chenms',41,'dragonfly','ubb','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8f27e51d582a50bac460cd4bf8d581e4beed7b21\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"ameiurl@gmail.com\",\"AuthorName\":\"chenms\",\"CommitterEmail\":\"ameiurl@gmail.com\",\"CommitterName\":\"chenms\",\"Timestamp\":\"2019-11-05T17:20:22+08:00\"}],\"CompareURL\":\"\"}',1572945644),(246,1,1,1,'chenms',43,'dragonfly','foundation','',0,'',1597753528),(247,4,1,1,'chenms',43,'dragonfly','foundation','',0,'',1597753528),(248,1,16,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8afa255b4a71f068fb51c605d5b820bc0b5ac544\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T20:36:39+08:00\"}],\"CompareURL\":\"\"}',1597754210),(249,4,16,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8afa255b4a71f068fb51c605d5b820bc0b5ac544\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T20:36:39+08:00\"}],\"CompareURL\":\"\"}',1597754210),(250,1,5,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8afa255b4a71f068fb51c605d5b820bc0b5ac544\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T20:36:39+08:00\"}],\"CompareURL\":\"\"}',1597754210),(251,4,5,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"8afa255b4a71f068fb51c605d5b820bc0b5ac544\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T20:36:39+08:00\"}],\"CompareURL\":\"\"}',1597754210),(252,1,5,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"36bb4c062db1e26255601b0cabd7aa47766d8a50\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T21:50:20+08:00\"}],\"CompareURL\":\"dragonfly/foundation/compare/8afa255b4a71f068fb51c605d5b820bc0b5ac544...36bb4c062db1e26255601b0cabd7aa47766d8a50\"}',1597758622),(253,4,5,1,'chenms',43,'dragonfly','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"36bb4c062db1e26255601b0cabd7aa47766d8a50\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T21:50:20+08:00\"}],\"CompareURL\":\"dragonfly/foundation/compare/8afa255b4a71f068fb51c605d5b820bc0b5ac544...36bb4c062db1e26255601b0cabd7aa47766d8a50\"}',1597758622),(254,1,1,1,'chenms',44,'dragonfly','api','',0,'',1597759558),(255,4,1,1,'chenms',44,'dragonfly','api','',0,'',1597759558),(256,1,16,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a52d844d89f75e203d744a6e736d52f1cd4ec799\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:06:24+08:00\"}],\"CompareURL\":\"\"}',1597759595),(257,4,16,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a52d844d89f75e203d744a6e736d52f1cd4ec799\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:06:24+08:00\"}],\"CompareURL\":\"\"}',1597759595),(258,1,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a52d844d89f75e203d744a6e736d52f1cd4ec799\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:06:24+08:00\"}],\"CompareURL\":\"\"}',1597759595),(259,4,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a52d844d89f75e203d744a6e736d52f1cd4ec799\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:06:24+08:00\"}],\"CompareURL\":\"\"}',1597759595),(260,1,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4a21434e6052694c27d7dcdd78c08231ff4c33fd\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:13:35+08:00\"}],\"CompareURL\":\"dragonfly/api/compare/a52d844d89f75e203d744a6e736d52f1cd4ec799...4a21434e6052694c27d7dcdd78c08231ff4c33fd\"}',1597760017),(261,4,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4a21434e6052694c27d7dcdd78c08231ff4c33fd\",\"Message\":\"feat: 测试框架\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-18T22:13:35+08:00\"}],\"CompareURL\":\"dragonfly/api/compare/a52d844d89f75e203d744a6e736d52f1cd4ec799...4a21434e6052694c27d7dcdd78c08231ff4c33fd\"}',1597760017),(263,1,1,1,'chenms',45,'chenms','ddd','',0,'',1598581514),(264,1,16,1,'chenms',45,'chenms','ddd','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"294f30af7a2d4b541ca8849eb3de1b38deda96e0\",\"Message\":\"feat: ddd\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-28T11:08:31+08:00\"}],\"CompareURL\":\"\"}',1598585363),(265,1,5,1,'chenms',45,'chenms','ddd','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"294f30af7a2d4b541ca8849eb3de1b38deda96e0\",\"Message\":\"feat: ddd\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-08-28T11:08:31+08:00\"}],\"CompareURL\":\"\"}',1598585364),(266,1,1,1,'chenms',46,'ddd','foundation','',0,'',1599214964),(267,5,1,1,'chenms',46,'ddd','foundation','',0,'',1599214964),(268,1,16,1,'chenms',46,'ddd','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c574b7448e5c9b2adbe97a23193f2771910bf4ab\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T18:23:40+08:00\"}],\"CompareURL\":\"\"}',1599215035),(269,5,16,1,'chenms',46,'ddd','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c574b7448e5c9b2adbe97a23193f2771910bf4ab\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T18:23:40+08:00\"}],\"CompareURL\":\"\"}',1599215035),(270,1,5,1,'chenms',46,'ddd','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c574b7448e5c9b2adbe97a23193f2771910bf4ab\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T18:23:40+08:00\"}],\"CompareURL\":\"\"}',1599215035),(271,5,5,1,'chenms',46,'ddd','foundation','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c574b7448e5c9b2adbe97a23193f2771910bf4ab\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T18:23:40+08:00\"}],\"CompareURL\":\"\"}',1599215035),(272,1,1,1,'chenms',47,'firefly','satis-config-local','',0,'',1599222746),(273,3,1,1,'chenms',47,'firefly','satis-config-local','',0,'',1599222746),(274,1,16,1,'chenms',47,'firefly','satis-config-local','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"857f007149f4b5fa39e954d1b2a1ae323e92b481\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T20:32:45+08:00\"}],\"CompareURL\":\"\"}',1599222778),(275,3,16,1,'chenms',47,'firefly','satis-config-local','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"857f007149f4b5fa39e954d1b2a1ae323e92b481\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T20:32:45+08:00\"}],\"CompareURL\":\"\"}',1599222778),(276,1,5,1,'chenms',47,'firefly','satis-config-local','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"857f007149f4b5fa39e954d1b2a1ae323e92b481\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T20:32:45+08:00\"}],\"CompareURL\":\"\"}',1599222778),(277,3,5,1,'chenms',47,'firefly','satis-config-local','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"857f007149f4b5fa39e954d1b2a1ae323e92b481\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-04T20:32:45+08:00\"}],\"CompareURL\":\"\"}',1599222778),(278,1,1,1,'chenms',48,'ddd','trade','',0,'',1599310100),(279,5,1,1,'chenms',48,'ddd','trade','',0,'',1599310100),(280,1,16,1,'chenms',48,'ddd','trade','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3c041198f2ce8b690fa17482d632cffcf8b396db\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:09+08:00\"}],\"CompareURL\":\"\"}',1599310224),(281,5,16,1,'chenms',48,'ddd','trade','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3c041198f2ce8b690fa17482d632cffcf8b396db\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:09+08:00\"}],\"CompareURL\":\"\"}',1599310224),(282,1,5,1,'chenms',48,'ddd','trade','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3c041198f2ce8b690fa17482d632cffcf8b396db\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:09+08:00\"}],\"CompareURL\":\"\"}',1599310224),(283,5,5,1,'chenms',48,'ddd','trade','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3c041198f2ce8b690fa17482d632cffcf8b396db\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:09+08:00\"}],\"CompareURL\":\"\"}',1599310224),(284,1,1,1,'chenms',49,'ddd','gds','',0,'',1599310258),(285,5,1,1,'chenms',49,'ddd','gds','',0,'',1599310258),(286,1,16,1,'chenms',49,'ddd','gds','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1bd5857641f8a2f94756ffac6e908c5d5f2baf17\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:48+08:00\"}],\"CompareURL\":\"\"}',1599310268),(287,5,16,1,'chenms',49,'ddd','gds','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1bd5857641f8a2f94756ffac6e908c5d5f2baf17\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:48+08:00\"}],\"CompareURL\":\"\"}',1599310268),(288,1,5,1,'chenms',49,'ddd','gds','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1bd5857641f8a2f94756ffac6e908c5d5f2baf17\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:48+08:00\"}],\"CompareURL\":\"\"}',1599310268),(289,5,5,1,'chenms',49,'ddd','gds','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1bd5857641f8a2f94756ffac6e908c5d5f2baf17\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-05T20:50:48+08:00\"}],\"CompareURL\":\"\"}',1599310268),(290,1,1,1,'chenms',50,'chenms','satis-config','',0,'',1600155226),(291,1,16,1,'chenms',50,'chenms','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3ed97823190e6bc44f3f317b3f988fd637359ed1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-15T15:38:41+08:00\"}],\"CompareURL\":\"\"}',1600155594),(292,1,5,1,'chenms',50,'chenms','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3ed97823190e6bc44f3f317b3f988fd637359ed1\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-15T15:38:41+08:00\"}],\"CompareURL\":\"\"}',1600155594),(293,1,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0f0e3a5c34215fe74ee8d5fed7bc0a5d0971d670\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-15T15:42:49+08:00\"}],\"CompareURL\":\"dragonfly/api/compare/4a21434e6052694c27d7dcdd78c08231ff4c33fd...0f0e3a5c34215fe74ee8d5fed7bc0a5d0971d670\"}',1600155930),(294,4,5,1,'chenms',44,'dragonfly','api','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0f0e3a5c34215fe74ee8d5fed7bc0a5d0971d670\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-09-15T15:42:49+08:00\"}],\"CompareURL\":\"dragonfly/api/compare/4a21434e6052694c27d7dcdd78c08231ff4c33fd...0f0e3a5c34215fe74ee8d5fed7bc0a5d0971d670\"}',1600155930),(295,1,1,1,'chenms',51,'cncn','conf.d','',0,'',1602299370),(296,6,1,1,'chenms',51,'cncn','conf.d','',0,'',1602299370),(297,1,16,1,'chenms',51,'cncn','conf.d','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c2181669cdcf11a91a4241ee83a83dff657a79d7\",\"Message\":\"feat: cncn的nginx配置库\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T11:10:42+08:00\"}],\"CompareURL\":\"\"}',1602299748),(298,6,16,1,'chenms',51,'cncn','conf.d','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c2181669cdcf11a91a4241ee83a83dff657a79d7\",\"Message\":\"feat: cncn的nginx配置库\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T11:10:42+08:00\"}],\"CompareURL\":\"\"}',1602299748),(299,1,5,1,'chenms',51,'cncn','conf.d','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c2181669cdcf11a91a4241ee83a83dff657a79d7\",\"Message\":\"feat: cncn的nginx配置库\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T11:10:42+08:00\"}],\"CompareURL\":\"\"}',1602299748),(300,6,5,1,'chenms',51,'cncn','conf.d','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c2181669cdcf11a91a4241ee83a83dff657a79d7\",\"Message\":\"feat: cncn的nginx配置库\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T11:10:42+08:00\"}],\"CompareURL\":\"\"}',1602299748),(301,1,1,1,'chenms',52,'chenms','firefly_doc','',0,'',1602318287),(302,1,16,1,'chenms',52,'chenms','firefly_doc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ab400f89e0b5429394cd2ad25c1e0b868a77d560\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:26:26+08:00\"}],\"CompareURL\":\"\"}',1602318434),(303,1,5,1,'chenms',52,'chenms','firefly_doc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ab400f89e0b5429394cd2ad25c1e0b868a77d560\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:26:26+08:00\"}],\"CompareURL\":\"\"}',1602318434),(304,1,1,1,'chenms',53,'cncn','chat.cncn.com','',0,'',1602318826),(305,6,1,1,'chenms',53,'cncn','chat.cncn.com','',0,'',1602318826),(306,1,16,1,'chenms',53,'cncn','chat.cncn.com','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"61e1ff9ca03a9bf4826959b10272cf3dca0dc522\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:35:52+08:00\"}],\"CompareURL\":\"\"}',1602318967),(307,6,16,1,'chenms',53,'cncn','chat.cncn.com','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"61e1ff9ca03a9bf4826959b10272cf3dca0dc522\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:35:52+08:00\"}],\"CompareURL\":\"\"}',1602318967),(308,1,5,1,'chenms',53,'cncn','chat.cncn.com','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"61e1ff9ca03a9bf4826959b10272cf3dca0dc522\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:35:52+08:00\"}],\"CompareURL\":\"\"}',1602318967),(309,6,5,1,'chenms',53,'cncn','chat.cncn.com','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"61e1ff9ca03a9bf4826959b10272cf3dca0dc522\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:35:52+08:00\"}],\"CompareURL\":\"\"}',1602318967),(310,1,1,1,'chenms',54,'cncn','api_new_v2','',0,'',1602319072),(311,6,1,1,'chenms',54,'cncn','api_new_v2','',0,'',1602319072),(312,1,16,1,'chenms',54,'cncn','api_new_v2','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee5ea45a43ad66f70335573998f18fa37a8f8091\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:37:39+08:00\"}],\"CompareURL\":\"\"}',1602319085),(313,6,16,1,'chenms',54,'cncn','api_new_v2','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee5ea45a43ad66f70335573998f18fa37a8f8091\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:37:39+08:00\"}],\"CompareURL\":\"\"}',1602319085),(314,1,5,1,'chenms',54,'cncn','api_new_v2','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee5ea45a43ad66f70335573998f18fa37a8f8091\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:37:39+08:00\"}],\"CompareURL\":\"\"}',1602319085),(315,6,5,1,'chenms',54,'cncn','api_new_v2','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee5ea45a43ad66f70335573998f18fa37a8f8091\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:37:39+08:00\"}],\"CompareURL\":\"\"}',1602319085),(316,1,1,1,'chenms',55,'cncn','rpc','',0,'',1602319242),(317,6,1,1,'chenms',55,'cncn','rpc','',0,'',1602319242),(318,1,16,1,'chenms',55,'cncn','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"578b761d720865572d5ff346fa01a830c805c62c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:41:12+08:00\"}],\"CompareURL\":\"\"}',1602319284),(319,6,16,1,'chenms',55,'cncn','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"578b761d720865572d5ff346fa01a830c805c62c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:41:12+08:00\"}],\"CompareURL\":\"\"}',1602319284),(320,1,5,1,'chenms',55,'cncn','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"578b761d720865572d5ff346fa01a830c805c62c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:41:12+08:00\"}],\"CompareURL\":\"\"}',1602319284),(321,6,5,1,'chenms',55,'cncn','rpc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"578b761d720865572d5ff346fa01a830c805c62c\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:41:12+08:00\"}],\"CompareURL\":\"\"}',1602319284),(322,1,1,1,'chenms',56,'cncn','erp','',0,'',1602319338),(323,6,1,1,'chenms',56,'cncn','erp','',0,'',1602319338),(324,1,16,1,'chenms',56,'cncn','erp','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"820462dc358d042c3484554701e3a62f4f91d61b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:51:30+08:00\"}],\"CompareURL\":\"\"}',1602320809),(325,6,16,1,'chenms',56,'cncn','erp','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"820462dc358d042c3484554701e3a62f4f91d61b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:51:30+08:00\"}],\"CompareURL\":\"\"}',1602320809),(326,1,5,1,'chenms',56,'cncn','erp','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"820462dc358d042c3484554701e3a62f4f91d61b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:51:30+08:00\"}],\"CompareURL\":\"\"}',1602320809),(327,6,5,1,'chenms',56,'cncn','erp','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"820462dc358d042c3484554701e3a62f4f91d61b\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-10T16:51:30+08:00\"}],\"CompareURL\":\"\"}',1602320809),(328,1,5,1,'chenms',50,'chenms','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"d0ee28e4fc76affd2740744c2b709864c7a04177\",\"Message\":\"change: 内网地址更改\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-15T09:26:08+08:00\"}],\"CompareURL\":\"chenms/satis-config/compare/3ed97823190e6bc44f3f317b3f988fd637359ed1...d0ee28e4fc76affd2740744c2b709864c7a04177\"}',1602725175),(329,1,5,1,'chenms',50,'chenms','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2492bf1f7ad6cfcb417f8c7e5c8774c9f73293c9\",\"Message\":\"first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-17T11:50:49+08:00\"}],\"CompareURL\":\"chenms/satis-config/compare/d0ee28e4fc76affd2740744c2b709864c7a04177...2492bf1f7ad6cfcb417f8c7e5c8774c9f73293c9\"}',1602906653),(330,1,1,1,'chenms',57,'cncn','php-standards','',0,'',1603521559),(331,6,1,1,'chenms',57,'cncn','php-standards','',0,'',1603521559),(332,1,16,1,'chenms',57,'cncn','php-standards','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0af6b0c897e79046b601593f61c34acaaa68aee1\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:39:50+08:00\"}],\"CompareURL\":\"\"}',1603521602),(333,6,16,1,'chenms',57,'cncn','php-standards','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0af6b0c897e79046b601593f61c34acaaa68aee1\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:39:50+08:00\"}],\"CompareURL\":\"\"}',1603521602),(334,1,5,1,'chenms',57,'cncn','php-standards','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0af6b0c897e79046b601593f61c34acaaa68aee1\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:39:50+08:00\"}],\"CompareURL\":\"\"}',1603521602),(335,6,5,1,'chenms',57,'cncn','php-standards','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0af6b0c897e79046b601593f61c34acaaa68aee1\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:39:50+08:00\"}],\"CompareURL\":\"\"}',1603521602),(336,1,1,1,'chenms',58,'cncn','git_usage','',0,'',1603521734),(337,6,1,1,'chenms',58,'cncn','git_usage','',0,'',1603521734),(338,1,16,1,'chenms',58,'cncn','git_usage','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5ca69c40e76511d1ed0109f146c89546b29ddf06\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:42:42+08:00\"}],\"CompareURL\":\"\"}',1603521807),(339,6,16,1,'chenms',58,'cncn','git_usage','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5ca69c40e76511d1ed0109f146c89546b29ddf06\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:42:42+08:00\"}],\"CompareURL\":\"\"}',1603521807),(340,1,5,1,'chenms',58,'cncn','git_usage','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5ca69c40e76511d1ed0109f146c89546b29ddf06\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:42:42+08:00\"}],\"CompareURL\":\"\"}',1603521807),(341,6,5,1,'chenms',58,'cncn','git_usage','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5ca69c40e76511d1ed0109f146c89546b29ddf06\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:42:42+08:00\"}],\"CompareURL\":\"\"}',1603521807),(342,1,1,1,'chenms',59,'cncn','cncn_api_sdk','',0,'',1603521877),(343,6,1,1,'chenms',59,'cncn','cncn_api_sdk','',0,'',1603521877),(344,1,16,1,'chenms',59,'cncn','cncn_api_sdk','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9718e9e94e95f42ffc5d69e288da46fb4bc44eb8\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:44:59+08:00\"}],\"CompareURL\":\"\"}',1603521910),(345,6,16,1,'chenms',59,'cncn','cncn_api_sdk','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9718e9e94e95f42ffc5d69e288da46fb4bc44eb8\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:44:59+08:00\"}],\"CompareURL\":\"\"}',1603521910),(346,1,5,1,'chenms',59,'cncn','cncn_api_sdk','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9718e9e94e95f42ffc5d69e288da46fb4bc44eb8\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:44:59+08:00\"}],\"CompareURL\":\"\"}',1603521910),(347,6,5,1,'chenms',59,'cncn','cncn_api_sdk','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9718e9e94e95f42ffc5d69e288da46fb4bc44eb8\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:44:59+08:00\"}],\"CompareURL\":\"\"}',1603521910),(348,1,1,1,'chenms',60,'cncn','api_guide','',0,'',1603521951),(349,6,1,1,'chenms',60,'cncn','api_guide','',0,'',1603521951),(350,1,16,1,'chenms',60,'cncn','api_guide','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f00653cdccdc8a7ea22d43624efa8534af6dcc0e\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:46:10+08:00\"}],\"CompareURL\":\"\"}',1603521993),(351,6,16,1,'chenms',60,'cncn','api_guide','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f00653cdccdc8a7ea22d43624efa8534af6dcc0e\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:46:10+08:00\"}],\"CompareURL\":\"\"}',1603521993),(352,1,5,1,'chenms',60,'cncn','api_guide','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f00653cdccdc8a7ea22d43624efa8534af6dcc0e\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:46:10+08:00\"}],\"CompareURL\":\"\"}',1603521993),(353,6,5,1,'chenms',60,'cncn','api_guide','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f00653cdccdc8a7ea22d43624efa8534af6dcc0e\",\"Message\":\"feat: first commit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2020-10-24T14:46:10+08:00\"}],\"CompareURL\":\"\"}',1603521993),(354,1,1,1,'chenms',61,'backup','phpcode','',0,'',1713111320),(355,7,1,1,'chenms',61,'backup','phpcode','',0,'',1713111320),(356,1,16,1,'chenms',61,'backup','phpcode','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"de685193a931edbf947c6dccaa47ccc87ec90698\",\"Message\":\"phpcode\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T00:15:41+08:00\"}],\"CompareURL\":\"\"}',1713111377),(357,7,16,1,'chenms',61,'backup','phpcode','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"de685193a931edbf947c6dccaa47ccc87ec90698\",\"Message\":\"phpcode\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T00:15:41+08:00\"}],\"CompareURL\":\"\"}',1713111377),(358,1,5,1,'chenms',61,'backup','phpcode','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"de685193a931edbf947c6dccaa47ccc87ec90698\",\"Message\":\"phpcode\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T00:15:41+08:00\"}],\"CompareURL\":\"\"}',1713111377),(359,7,5,1,'chenms',61,'backup','phpcode','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"de685193a931edbf947c6dccaa47ccc87ec90698\",\"Message\":\"phpcode\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T00:15:41+08:00\"}],\"CompareURL\":\"\"}',1713111377),(360,1,5,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ad8cd68aedf327a0c8745e9d59195bc2f9f9cc62\",\"Message\":\"edit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T05:25:47+08:00\"}],\"CompareURL\":\"firefly/satis-config/compare/7f7a6162a8c7dbb7e914a441b76c00bee7bdd275...ad8cd68aedf327a0c8745e9d59195bc2f9f9cc62\"}',1713129953),(361,3,5,1,'chenms',34,'firefly','satis-config','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ad8cd68aedf327a0c8745e9d59195bc2f9f9cc62\",\"Message\":\"edit\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2024-04-15T05:25:47+08:00\"}],\"CompareURL\":\"firefly/satis-config/compare/7f7a6162a8c7dbb7e914a441b76c00bee7bdd275...ad8cd68aedf327a0c8745e9d59195bc2f9f9cc62\"}',1713129953),(366,1,1,1,'chenms',64,'chenms','qgsc','',0,'',1740408520),(367,1,16,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"d69b77f9b69dd80b9b26b7df404b6dda1cddafe9\",\"Message\":\"qgsc\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-02-24T22:48:04+08:00\"}],\"CompareURL\":\"\"}',1740408524),(368,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"d69b77f9b69dd80b9b26b7df404b6dda1cddafe9\",\"Message\":\"qgsc\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-02-24T22:48:04+08:00\"}],\"CompareURL\":\"\"}',1740408524),(369,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"bbc914e15b5f5b0da5555661abccc509dca6b0b9\",\"Message\":\"增加下单送积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-02-25T02:17:49+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/d69b77f9b69dd80b9b26b7df404b6dda1cddafe9...bbc914e15b5f5b0da5555661abccc509dca6b0b9\"}',1740421080),(370,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0c019d713455f548d29996177a04d7062b3f76d7\",\"Message\":\"增加下单送积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-02-25T18:52:47+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/bbc914e15b5f5b0da5555661abccc509dca6b0b9...0c019d713455f548d29996177a04d7062b3f76d7\"}',1740480770),(371,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"888811b0ad638f8894c835dc2f4aaca86c312af2\",\"Message\":\"增加下单送积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-02-27T03:09:28+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/0c019d713455f548d29996177a04d7062b3f76d7...888811b0ad638f8894c835dc2f4aaca86c312af2\"}',1740596971),(372,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"c743fef7997d78e265ae48c7466573c4cb50d157\",\"Message\":\"银行账户增加用户名称修改\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-02T01:53:44+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/888811b0ad638f8894c835dc2f4aaca86c312af2...c743fef7997d78e265ae48c7466573c4cb50d157\"}',1740851628),(373,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ff67627f4427a032bab75c30b9075178d4394e8d\",\"Message\":\"留言内容\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-03T17:59:16+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/c743fef7997d78e265ae48c7466573c4cb50d157...ff67627f4427a032bab75c30b9075178d4394e8d\"}',1740995960),(374,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"46d22708ff5d1ab40a62e62f67c8d68aed49a735\",\"Message\":\"留言内容\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-05T00:47:51+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/ff67627f4427a032bab75c30b9075178d4394e8d...46d22708ff5d1ab40a62e62f67c8d68aed49a735\"}',1741106873),(375,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee2d52272551399f1b4f6142c136003d97f8bcaf\",\"Message\":\"留言内容\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-05T00:49:26+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/46d22708ff5d1ab40a62e62f67c8d68aed49a735...ee2d52272551399f1b4f6142c136003d97f8bcaf\"}',1741106968),(376,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"cd33b98d5909209f5bf53f6797dd956d61d0ab9b\",\"Message\":\"留言内容\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-05T02:01:36+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/ee2d52272551399f1b4f6142c136003d97f8bcaf...cd33b98d5909209f5bf53f6797dd956d61d0ab9b\"}',1741111298),(377,1,2,1,'chenms',45,'chenms','erp_doraemon','',0,'ddd',1742301377),(379,1,1,1,'chenms',65,'chenms','test','',0,'',1742545238),(380,1,16,1,'chenms',65,'chenms','test','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1d6abfb9bc3d1b950224dd376d2ea2641ad13a15\",\"Message\":\"test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-21T16:21:02+08:00\"}],\"CompareURL\":\"\"}',1742545310),(381,1,5,1,'chenms',65,'chenms','test','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1d6abfb9bc3d1b950224dd376d2ea2641ad13a15\",\"Message\":\"test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-21T16:21:02+08:00\"}],\"CompareURL\":\"\"}',1742545310),(382,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3eac63d76a54d0cb0625de0e6d0beffa3cefce02\",\"Message\":\"分享二维码\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-28T22:40:53+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/cd33b98d5909209f5bf53f6797dd956d61d0ab9b...3eac63d76a54d0cb0625de0e6d0beffa3cefce02\"}',1743172858),(383,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0552e5b9968b22607a023779007bdb180f94d433\",\"Message\":\"分享二维码\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-03-28T22:48:19+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/3eac63d76a54d0cb0625de0e6d0beffa3cefce02...0552e5b9968b22607a023779007bdb180f94d433\"}',1743173300),(384,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a3c3c018232a0007c454131a653780436c528c2b\",\"Message\":\"增加分红积分，扣款\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-06T18:58:32+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/0552e5b9968b22607a023779007bdb180f94d433...a3c3c018232a0007c454131a653780436c528c2b\"}',1743937116),(385,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"06b9631175003450f81ea1c3ff83d6a903a13245\",\"Message\":\"增加分红积分，扣绿色积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-11T21:51:29+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/a3c3c018232a0007c454131a653780436c528c2b...06b9631175003450f81ea1c3ff83d6a903a13245\"}',1744379494),(386,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"960011f2b9d2f6d43e4235e67adf44b895982d6d\",\"Message\":\"纯利润分红积分，扣绿色积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-13T20:06:18+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/06b9631175003450f81ea1c3ff83d6a903a13245...960011f2b9d2f6d43e4235e67adf44b895982d6d\"}',1744545982),(387,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"1a71bfd3df93fbaf8d3fdc1b953732df5143159c\",\"Message\":\"寄售跳过线下支付，用绿色积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-15T09:01:30+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/960011f2b9d2f6d43e4235e67adf44b895982d6d...1a71bfd3df93fbaf8d3fdc1b953732df5143159c\"}',1744678895),(388,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a54e20acf1d49dc41bbd4a2f469f68942710d4f6\",\"Message\":\"寄售跳过线下支付，用绿色积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-15T14:12:56+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/1a71bfd3df93fbaf8d3fdc1b953732df5143159c...a54e20acf1d49dc41bbd4a2f469f68942710d4f6\"}',1744697577),(389,1,5,1,'chenms',64,'chenms','qgsc','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b1081a512d48296d1d57f6c98a38a5a922a2581d\",\"Message\":\"寄售跳过线下支付，用绿色积分\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-04-16T07:39:52+08:00\"}],\"CompareURL\":\"chenms/qgsc/compare/a54e20acf1d49dc41bbd4a2f469f68942710d4f6...b1081a512d48296d1d57f6c98a38a5a922a2581d\"}',1744760394),(393,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0b42a22ec03b8a5d8f0ec160309b4049434ab8a6\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T09:21:54+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/294f30af7a2d4b541ca8849eb3de1b38deda96e0...0b42a22ec03b8a5d8f0ec160309b4049434ab8a6\"}',1749259317),(394,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"84f57b8be08f8e26768ee4165af35ae19fcd45bd\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T09:57:47+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/0b42a22ec03b8a5d8f0ec160309b4049434ab8a6...84f57b8be08f8e26768ee4165af35ae19fcd45bd\"}',1749261469),(395,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"896c16d0e92e854688adc02563a86910de079411\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T10:43:03+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/294f30af7a2d4b541ca8849eb3de1b38deda96e0...896c16d0e92e854688adc02563a86910de079411\"}',1749264865),(396,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"bf9e354f7e756bee2d6cb43057eff011f8433e7e\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T12:18:29+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/896c16d0e92e854688adc02563a86910de079411...bf9e354f7e756bee2d6cb43057eff011f8433e7e\"}',1749269911),(397,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"4d5ccf6ed383cb698da326955e59718af9eb2923\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T12:20:14+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/bf9e354f7e756bee2d6cb43057eff011f8433e7e...4d5ccf6ed383cb698da326955e59718af9eb2923\"}',1749270016),(398,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"3448abd12688c8ab0d946125aa6efe71b1caf3fe\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T12:22:34+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/4d5ccf6ed383cb698da326955e59718af9eb2923...3448abd12688c8ab0d946125aa6efe71b1caf3fe\"}',1749270156),(399,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"baaa8b4375c493d70c8096db8e8c6dd85ca9f626\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T12:28:37+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/3448abd12688c8ab0d946125aa6efe71b1caf3fe...baaa8b4375c493d70c8096db8e8c6dd85ca9f626\"}',1749270519),(400,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ee9db6ae5829028f34a49ac0cc78faa377773b45\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:23:14+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/baaa8b4375c493d70c8096db8e8c6dd85ca9f626...ee9db6ae5829028f34a49ac0cc78faa377773b45\"}',1749273795),(401,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"cc5e84e2cd04779bbc4a29199a492d9cae320f7d\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:36:12+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/ee9db6ae5829028f34a49ac0cc78faa377773b45...cc5e84e2cd04779bbc4a29199a492d9cae320f7d\"}',1749274574),(402,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2f873c228eeef8a3270b11ff7570aa46e284c149\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:42:44+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/cc5e84e2cd04779bbc4a29199a492d9cae320f7d...2f873c228eeef8a3270b11ff7570aa46e284c149\"}',1749274968),(403,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"0947610c6b3ef1aa042251091f9e8a273f14adbe\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:43:37+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/2f873c228eeef8a3270b11ff7570aa46e284c149...0947610c6b3ef1aa042251091f9e8a273f14adbe\"}',1749275018),(404,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"5773992a3325438f87a921ec3cdcc72720d2c817\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:44:24+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/0947610c6b3ef1aa042251091f9e8a273f14adbe...5773992a3325438f87a921ec3cdcc72720d2c817\"}',1749275068),(405,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"94343b3f0bef841d4557318c465890a6c39a9ca1\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:53:00+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/5773992a3325438f87a921ec3cdcc72720d2c817...94343b3f0bef841d4557318c465890a6c39a9ca1\"}',1749275582),(406,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"b3e2835522fd7e01e5ee052bd98267ee621d3417\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:53:44+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/94343b3f0bef841d4557318c465890a6c39a9ca1...b3e2835522fd7e01e5ee052bd98267ee621d3417\"}',1749275625),(407,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"ac0c320edb0a6c0c7bf80e838febb6b2c19628ed\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T13:56:53+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/b3e2835522fd7e01e5ee052bd98267ee621d3417...ac0c320edb0a6c0c7bf80e838febb6b2c19628ed\"}',1749275817),(408,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"f094d3b0c0dd8915882696e0dbd1ea0a4bad2527\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T14:05:11+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/ac0c320edb0a6c0c7bf80e838febb6b2c19628ed...f094d3b0c0dd8915882696e0dbd1ea0a4bad2527\"}',1749276313),(409,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"9841f9c4c1ff9d1d7df51728616875ac8d013704\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T14:22:46+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/f094d3b0c0dd8915882696e0dbd1ea0a4bad2527...9841f9c4c1ff9d1d7df51728616875ac8d013704\"}',1749277367),(410,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"90609cedc7257015fbdef480bdafc69979c95f46\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T14:26:56+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/9841f9c4c1ff9d1d7df51728616875ac8d013704...90609cedc7257015fbdef480bdafc69979c95f46\"}',1749277618),(411,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"2cc2463a63a05f59b98ed56477e415f52e1f56f6\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T14:31:28+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/90609cedc7257015fbdef480bdafc69979c95f46...2cc2463a63a05f59b98ed56477e415f52e1f56f6\"}',1749277890),(412,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"e1fe7a7157e1791820ed33f4ef283db8442323f3\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T14:31:45+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/2cc2463a63a05f59b98ed56477e415f52e1f56f6...e1fe7a7157e1791820ed33f4ef283db8442323f3\"}',1749277909),(414,1,1,1,'chenms',70,'chenms','rsync','',0,'',1749297097),(415,1,5,1,'chenms',45,'chenms','erp_doraemon','master',0,'{\"Len\":1,\"Commits\":[{\"Sha1\":\"a8e94833f07e70d7152dc3ef218a06f344218b15\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T19:54:30+08:00\"}],\"CompareURL\":\"chenms/erp_doraemon/compare/e1fe7a7157e1791820ed33f4ef283db8442323f3...a8e94833f07e70d7152dc3ef218a06f344218b15\"}',1749297273),(416,1,16,1,'chenms',70,'chenms','rsync','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"2022215549ad00dd913cf595fae67d5d1d20844d\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T19:46:59+08:00\"},{\"Sha1\":\"648b00d4b6481e277e45409871f1f28c5dae005a\",\"Message\":\"rsync\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-06T09:20:08+08:00\"}],\"CompareURL\":\"\"}',1749297498),(417,1,5,1,'chenms',70,'chenms','rsync','master',0,'{\"Len\":2,\"Commits\":[{\"Sha1\":\"2022215549ad00dd913cf595fae67d5d1d20844d\",\"Message\":\"rsync test\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-07T19:46:59+08:00\"},{\"Sha1\":\"648b00d4b6481e277e45409871f1f28c5dae005a\",\"Message\":\"rsync\\n\",\"AuthorEmail\":\"cms1984@msn.com\",\"AuthorName\":\"amei\",\"CommitterEmail\":\"cms1984@msn.com\",\"CommitterName\":\"amei\",\"Timestamp\":\"2025-06-06T09:20:08+08:00\"}],\"CompareURL\":\"\"}',1749297498);
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `issue_id` bigint DEFAULT NULL,
  `comment_id` bigint DEFAULT NULL,
  `release_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_attachment_uuid` (`uuid`),
  KEY `IDX_attachment_issue_id` (`issue_id`),
  KEY `IDX_attachment_release_id` (`release_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collaboration`
--

DROP TABLE IF EXISTS `collaboration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collaboration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `mode` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_collaboration_s` (`repo_id`,`user_id`),
  KEY `IDX_collaboration_repo_id` (`repo_id`),
  KEY `IDX_collaboration_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collaboration`
--

LOCK TABLES `collaboration` WRITE;
/*!40000 ALTER TABLE `collaboration` DISABLE KEYS */;
/*!40000 ALTER TABLE `collaboration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `poster_id` bigint DEFAULT NULL,
  `issue_id` bigint DEFAULT NULL,
  `commit_id` bigint DEFAULT NULL,
  `line` bigint DEFAULT NULL,
  `content` text,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  `commit_sha` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_comment_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deploy_key`
--

DROP TABLE IF EXISTS `deploy_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deploy_key` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `fingerprint` varchar(255) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_deploy_key_s` (`key_id`,`repo_id`),
  KEY `IDX_deploy_key_key_id` (`key_id`),
  KEY `IDX_deploy_key_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deploy_key`
--

LOCK TABLES `deploy_key` WRITE;
/*!40000 ALTER TABLE `deploy_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `deploy_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_address`
--

DROP TABLE IF EXISTS `email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` bigint NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_activated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_email_address_email` (`email`),
  KEY `IDX_email_address_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_address`
--

LOCK TABLES `email_address` WRITE;
/*!40000 ALTER TABLE `email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow`
--

DROP TABLE IF EXISTS `follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `follow_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_follow_follow` (`user_id`,`follow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow`
--

LOCK TABLES `follow` WRITE;
/*!40000 ALTER TABLE `follow` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hook_task`
--

DROP TABLE IF EXISTS `hook_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hook_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `hook_id` bigint DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `url` text,
  `signature` text,
  `payload_content` text,
  `content_type` int DEFAULT NULL,
  `event_type` varchar(255) DEFAULT NULL,
  `is_ssl` tinyint(1) DEFAULT NULL,
  `is_delivered` tinyint(1) DEFAULT NULL,
  `delivered` bigint DEFAULT NULL,
  `is_succeed` tinyint(1) DEFAULT NULL,
  `request_content` text,
  `response_content` text,
  PRIMARY KEY (`id`),
  KEY `IDX_hook_task_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hook_task`
--

LOCK TABLES `hook_task` WRITE;
/*!40000 ALTER TABLE `hook_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `hook_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue`
--

DROP TABLE IF EXISTS `issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `index` bigint DEFAULT NULL,
  `poster_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `milestone_id` bigint DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `assignee_id` bigint DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT NULL,
  `is_pull` tinyint(1) DEFAULT NULL,
  `num_comments` int DEFAULT NULL,
  `deadline_unix` bigint DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_repo_index` (`repo_id`,`index`),
  KEY `IDX_issue_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue`
--

LOCK TABLES `issue` WRITE;
/*!40000 ALTER TABLE `issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_label`
--

DROP TABLE IF EXISTS `issue_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_label` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `issue_id` bigint DEFAULT NULL,
  `label_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_label_s` (`issue_id`,`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_label`
--

LOCK TABLES `issue_label` WRITE;
/*!40000 ALTER TABLE `issue_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_user`
--

DROP TABLE IF EXISTS `issue_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` bigint DEFAULT NULL,
  `issue_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  `milestone_id` bigint DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `is_assigned` tinyint(1) DEFAULT NULL,
  `is_mentioned` tinyint(1) DEFAULT NULL,
  `is_poster` tinyint(1) DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_issue_user_uid` (`uid`),
  KEY `IDX_issue_user_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_user`
--

LOCK TABLES `issue_user` WRITE;
/*!40000 ALTER TABLE `issue_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `label` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `num_issues` int DEFAULT NULL,
  `num_closed_issues` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_label_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `label`
--

LOCK TABLES `label` WRITE;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
/*!40000 ALTER TABLE `label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lfs_object`
--

DROP TABLE IF EXISTS `lfs_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lfs_object` (
  `repo_id` bigint NOT NULL,
  `oid` varchar(191) NOT NULL,
  `size` bigint NOT NULL,
  `storage` longtext NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`repo_id`,`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lfs_object`
--

LOCK TABLES `lfs_object` WRITE;
/*!40000 ALTER TABLE `lfs_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfs_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_source`
--

DROP TABLE IF EXISTS `login_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_source` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_actived` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) DEFAULT '0',
  `cfg` text,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_login_source_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_source`
--

LOCK TABLES `login_source` WRITE;
/*!40000 ALTER TABLE `login_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestone`
--

DROP TABLE IF EXISTS `milestone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestone` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `is_closed` tinyint(1) DEFAULT NULL,
  `num_issues` int DEFAULT NULL,
  `num_closed_issues` int DEFAULT NULL,
  `completeness` int DEFAULT NULL,
  `deadline_unix` bigint DEFAULT NULL,
  `closed_date_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_milestone_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestone`
--

LOCK TABLES `milestone` WRITE;
/*!40000 ALTER TABLE `milestone` DISABLE KEYS */;
/*!40000 ALTER TABLE `milestone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mirror`
--

DROP TABLE IF EXISTS `mirror`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mirror` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `interval` int DEFAULT NULL,
  `enable_prune` tinyint(1) NOT NULL DEFAULT '1',
  `updated_unix` bigint DEFAULT NULL,
  `next_update_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mirror`
--

LOCK TABLES `mirror` WRITE;
/*!40000 ALTER TABLE `mirror` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirror` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `description` text,
  `created_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,1,'Failed to perform health check on repository \'/data/git/gogs-repositories/cncn/php-standards.git\': chdir /data/git/gogs-repositories/cncn/php-standards.git: no such file or directory',1742514613),(2,1,'Failed to perform health check on repository \'/data/git/gogs-repositories/cncn/git_usage.git\': chdir /data/git/gogs-repositories/cncn/git_usage.git: no such file or directory',1742514613),(3,1,'Failed to perform health check on repository \'/data/git/gogs-repositories/cncn/cncn_api_sdk.git\': chdir /data/git/gogs-repositories/cncn/cncn_api_sdk.git: no such file or directory',1742514613),(4,1,'Failed to perform health check on repository \'/data/git/gogs-repositories/cncn/api_guide.git\': chdir /data/git/gogs-repositories/cncn/api_guide.git: no such file or directory',1742514613),(5,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/chenms/firefly_doc.git\": chdir /data/git/gogs-repositories/chenms/firefly_doc.git: no such file or directory',1747275246),(6,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/erp.git\": chdir /data/git/gogs-repositories/cncn/erp.git: no such file or directory',1747275247),(7,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/php-standards.git\": chdir /data/git/gogs-repositories/cncn/php-standards.git: no such file or directory',1747275247),(8,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/git_usage.git\": chdir /data/git/gogs-repositories/cncn/git_usage.git: no such file or directory',1747275247),(9,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/cncn_api_sdk.git\": chdir /data/git/gogs-repositories/cncn/cncn_api_sdk.git: no such file or directory',1747275247),(10,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/api_guide.git\": chdir /data/git/gogs-repositories/cncn/api_guide.git: no such file or directory',1747275247),(11,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/chenms/firefly_doc.git\": chdir /data/git/gogs-repositories/chenms/firefly_doc.git: no such file or directory',1747361646),(12,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/erp.git\": chdir /data/git/gogs-repositories/cncn/erp.git: no such file or directory',1747361646),(13,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/php-standards.git\": chdir /data/git/gogs-repositories/cncn/php-standards.git: no such file or directory',1747361646),(14,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/git_usage.git\": chdir /data/git/gogs-repositories/cncn/git_usage.git: no such file or directory',1747361646),(15,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/cncn_api_sdk.git\": chdir /data/git/gogs-repositories/cncn/cncn_api_sdk.git: no such file or directory',1747361646),(16,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/api_guide.git\": chdir /data/git/gogs-repositories/cncn/api_guide.git: no such file or directory',1747361646),(17,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/chenms/firefly_doc.git\": chdir /data/git/gogs-repositories/chenms/firefly_doc.git: no such file or directory',1748866613),(18,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/erp.git\": chdir /data/git/gogs-repositories/cncn/erp.git: no such file or directory',1748866613),(19,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/php-standards.git\": chdir /data/git/gogs-repositories/cncn/php-standards.git: no such file or directory',1748866613),(20,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/git_usage.git\": chdir /data/git/gogs-repositories/cncn/git_usage.git: no such file or directory',1748866613),(21,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/cncn_api_sdk.git\": chdir /data/git/gogs-repositories/cncn/cncn_api_sdk.git: no such file or directory',1748866613),(22,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/api_guide.git\": chdir /data/git/gogs-repositories/cncn/api_guide.git: no such file or directory',1748866613),(23,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/chenms/firefly_doc.git\": chdir /data/git/gogs-repositories/chenms/firefly_doc.git: no such file or directory',1749602294),(24,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/erp.git\": chdir /data/git/gogs-repositories/cncn/erp.git: no such file or directory',1749602294),(25,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/php-standards.git\": chdir /data/git/gogs-repositories/cncn/php-standards.git: no such file or directory',1749602294),(26,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/git_usage.git\": chdir /data/git/gogs-repositories/cncn/git_usage.git: no such file or directory',1749602294),(27,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/cncn_api_sdk.git\": chdir /data/git/gogs-repositories/cncn/cncn_api_sdk.git: no such file or directory',1749602294),(28,1,'Failed to perform health check on repository \"/data/git/gogs-repositories/cncn/api_guide.git\": chdir /data/git/gogs-repositories/cncn/api_guide.git: no such file or directory',1749602294);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `org_user`
--

DROP TABLE IF EXISTS `org_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `org_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` bigint DEFAULT NULL,
  `org_id` bigint DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_owner` tinyint(1) DEFAULT NULL,
  `num_teams` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_org_user_s` (`uid`,`org_id`),
  KEY `IDX_org_user_uid` (`uid`),
  KEY `IDX_org_user_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `org_user`
--

LOCK TABLES `org_user` WRITE;
/*!40000 ALTER TABLE `org_user` DISABLE KEYS */;
INSERT INTO `org_user` VALUES (1,1,2,0,1,1),(2,1,3,0,1,1),(3,1,4,0,1,1),(4,1,5,0,1,1),(5,1,6,0,1,1),(6,1,7,0,1,1);
/*!40000 ALTER TABLE `org_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `protect_branch`
--

DROP TABLE IF EXISTS `protect_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `protect_branch` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `protected` tinyint(1) DEFAULT NULL,
  `require_pull_request` tinyint(1) DEFAULT NULL,
  `enable_whitelist` tinyint(1) DEFAULT NULL,
  `whitelist_user_i_ds` text,
  `whitelist_team_i_ds` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_protect_branch_protect_branch` (`repo_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protect_branch`
--

LOCK TABLES `protect_branch` WRITE;
/*!40000 ALTER TABLE `protect_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `protect_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `protect_branch_whitelist`
--

DROP TABLE IF EXISTS `protect_branch_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `protect_branch_whitelist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `protect_branch_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_protect_branch_whitelist_protect_branch_whitelist` (`repo_id`,`name`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protect_branch_whitelist`
--

LOCK TABLES `protect_branch_whitelist` WRITE;
/*!40000 ALTER TABLE `protect_branch_whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `protect_branch_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_key`
--

DROP TABLE IF EXISTS `public_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_key` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `mode` int NOT NULL DEFAULT '2',
  `type` int NOT NULL DEFAULT '1',
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_public_key_owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_key`
--

LOCK TABLES `public_key` WRITE;
/*!40000 ALTER TABLE `public_key` DISABLE KEYS */;
INSERT INTO `public_key` VALUES (7,1,'amei','SHA256:JPybnqyKa8+eiXBbIsME5+3ktv5i4yK2/7kwt3/FEv4','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCndVsqN4swdGlmLkX+78bwXg9oo3cMO4q5KkENfhbNZQLkMQsEu/5UdstKjVSPzPcYQqeOS5d+YtPfF2w7mxx5epfEM3NPVOwfb3qyURl86WJYJhuzVIm6ia/fsQGYjVhoFLPTifQfTZA88N2Pk2oUDer9yXKLJKc9SvmhP6NotbzxcJsPjSRhn/1oAcxnrmTs9/PkbZXJyjf7315MdMUAU162kkM50lS8IFiQ7oNpWukBr7J3Hb/a180A1BmMYFqq0MTexg117I7aTBvEKQ5l8Ia875uWTBDRFdZSlO4AzPGfDheFqH8RZVdMm+hoQnNHT6ZfsP7ntAU6O5MXS0xljq2NyzQuER3llqcsRx58qpnpifM4/vPY/1vQYfN9RXFIAdsatvPZ/+DJnXkzcb7JFLmQkDBc+XWkVnUHTO2SG/jijR6EO80/VksK7pcwJovJajfrsRe2J5fSbBJWjleCgvWZ46HmjRBkE07UEaDJI9XgNLSsI6HpmPMLoGJ6OD8= ameiurl@gmail.com',2,1,1602825488,1602912212),(8,1,'amei_ssh','SHA256:bgv8+z+1Ol5gO9iNeIVhtzUJEVfSS51MCoguU3pMEqM','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDX7onjlOvdCpxKOQvTrtJ+N3c8nk6KAaMakgWArCKsS6HGKJ7hUfd1eq25XitNVXBy/SwUIe/ys8G+si9i0sYY7n5PzgCL5zaHn5JGCgekemhLhOOlYfo5Yp+VhyzGxETqaCAFHwn1R5cOO29MUPtcW4fFgLvVo8tsvO55UOvQP7odcTizIIwjt5YzmRUiVbSXbqxgK67Ti4A/vzdXWGwtli1FN1NFuebG1W8AGSCqd5TpZjH/T2jpiLVdsajdmZ/GRoyj+/vQmpr4cjAYT/8RRQlylfS0wouh3OCWbzM7BEyl6QM4Rub/Kl9eeBDev827nOTGOxvxvZxkZeBoQAU63RYoFXrA1fCrVfoFs3h0/7TkTF0cXmJA0413vUfAo1pDNF8znsXlN1quvwH2L+X0lB7+Rtxpl3tpIO/qX1i37wGjx6LIzdVICu+WibxQQwodN83R9W1g22wYxOfWxhrumw40JVOWpz728R/V2NBpjLtPd3xRkiYUesIShIboer0= ameiurl@gmail.com',2,1,1606005535,1606006440),(9,1,'chenms_home','SHA256:kBX5mYA/ziPyGCJLD/lmi9mG8mVYtwGOl2OCGYqRSNY','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDWS3xwlL5FzHBFFQX+OCKST+SuoCoI2+1dTAt1wSRHx7tWTZAFAIGnEzEFlc8ctISv3LHmjGHqLSnVL3tB2z7vtXZ3/tUGGn8hN8QsB9eZ4ExircxP8hnft9YGEy6588xUKmcEAmaz7OR8UNZO9Zlqa3WfVxjM+bAtkKNAWjfmHYVaOJymQ+Ph+7gZZEVx4ezQPERUmvc5kqcRqqgotfQFk+MPuIgq1H6fb542bDo1oFuaTC/g7hZuJHtuKWgPtb8HuypbYwD1Zn8meTW9lbIjFSPyp09x3RHygT976ayChROfFkbYdyUN94yu4x1RlcKBFKQXNBMmPDL6aiJ3ebn84fZic+TOgjzOsvJPz2ok1sX0WSfkiFXlOQgmvPnKFg+2ocKzFvsbsCJA4V57y/5qMcj+OvgFNWV7m+Mzmrgc8QrnKki0evUy8CuMlnxj93d+AhV0UtQ8V0yh4PeFB8Rg1QwJqpVGZFxNNlbGOKrzbVxd7FuZKeup8dhgJ2Qvmec= ameiurl@gmail.com',2,1,1713111928,1744760394),(10,1,'home_root','SHA256:DSu3M9A4iRWbXiOM87Mpbeb3yTBF0m45ICHK8VY4xYw','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCmdgMDtcRKNn3xYPq582grSx2TrMSWajvR/Mw9eoBnFYrf4UP0McijT3t41m5sVnAOXVn5WmIT7LnP1yWhqAe9kmyNT7KP+ajN+qSL02mNoWU1KSGsF6Hzzsu18koi0sz1dFLtTAO8n6TYxsIHdBQNy+snYZiU1KCQ2XTqZquQzv3QWn+4WlPjz2Q5IR76jWkpPwEbbe+DiG+nughv58rcUz1TDIJV4t9mtwynlvAUe5T4t4fdO0HCy3DRI7/tiOtiRbrg+tgcuCIBCBs+1m1vcv2xdVw22k0LR7VrU4IR3Q//LbVLZvmb1hvLjbRUnQ+mjVQi+C6uyMfX7cwgR1cI0AAiwCEMB5lpHoTBNEnQa6+LRWj/figAt5Q7Qvk0wOo2SsAltNB22Ro3TXjNzBBOauBrSLzcjdOA8TV1gAf/dHULs3SYgtY9UXM7U3FDm9zqM2sI3pr8x5OWEROCNIeOSo4WYAnOiBGRclGsRb3YkQi5577gWFA/1Iatwqc5pTE= ameiurl@gmail.com',2,1,1713112326,1713129526),(13,1,'wind_vm','SHA256:dyVFZJfWYdQDuSlawMhsjv3uJNmy0TrHsCrYn13gCo0','ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC6ukX4fNZzcq4P7GUBJV8gmT3gfOjhNJYKgCltTUg1hTuGx+NQVSC70v0TiEk6Y9jt2p6/9H0+UlIFAvKBBZuXBdQ1QWPVUzgNUWiqD0RD2TcAq3C5oppeeH4Cv/A2yF9bNbUDupmsV123+q4hJq0Xxu5TFv9mZluLsd5B8ztUc69+2Va5ikzMsZjzj/Zr8lgS9vuJjJjiLOtCIXA/EnOi7fGUHqL2+1C6/7GZJUS9sz/d5QhaJu7GpxknwXT0r8r1bR/PmIYBAAGdRbIhQj9BG7ebhZDeEutuSHe9/25jqWI8BesYGb9nkC1rPpKSKJGAFN9s63wC8DTiL5v3SZ8m7BuCfls7+uismMo9oe5LhGSkDq1L326jGayTuodIAekE5r5WkgNvMFeRsVMnUx3J05zU5fOSo2DxTHd2VyGMUtsXTWwlgCd+NTAXtgcp0rEcYebjHchInxFPI0K6aezYET+pZbpIpXhigRp1/OebqzDlgTlCS0PrpOQsnsutVkU= ameiurl@gmail.com',2,1,1749297149,0);
/*!40000 ALTER TABLE `public_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pull_request`
--

DROP TABLE IF EXISTS `pull_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pull_request` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  `issue_id` bigint DEFAULT NULL,
  `index` bigint DEFAULT NULL,
  `head_repo_id` bigint DEFAULT NULL,
  `base_repo_id` bigint DEFAULT NULL,
  `head_user_name` varchar(255) DEFAULT NULL,
  `head_branch` varchar(255) DEFAULT NULL,
  `base_branch` varchar(255) DEFAULT NULL,
  `merge_base` varchar(40) DEFAULT NULL,
  `has_merged` tinyint(1) DEFAULT NULL,
  `merged_commit_id` varchar(40) DEFAULT NULL,
  `merger_id` bigint DEFAULT NULL,
  `merged_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_pull_request_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pull_request`
--

LOCK TABLES `pull_request` WRITE;
/*!40000 ALTER TABLE `pull_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `pull_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release`
--

DROP TABLE IF EXISTS `release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `release` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `publisher_id` bigint DEFAULT NULL,
  `tag_name` varchar(255) DEFAULT NULL,
  `lower_tag_name` varchar(255) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sha1` varchar(40) DEFAULT NULL,
  `num_commits` bigint DEFAULT NULL,
  `note` text,
  `is_draft` tinyint(1) NOT NULL DEFAULT '0',
  `is_prerelease` tinyint(1) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release`
--

LOCK TABLES `release` WRITE;
/*!40000 ALTER TABLE `release` DISABLE KEYS */;
/*!40000 ALTER TABLE `release` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository`
--

DROP TABLE IF EXISTS `repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repository` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_id` bigint DEFAULT NULL,
  `lower_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `default_branch` varchar(255) DEFAULT NULL,
  `size` bigint NOT NULL DEFAULT '0',
  `use_custom_avatar` tinyint(1) DEFAULT NULL,
  `num_watches` int DEFAULT NULL,
  `num_stars` int DEFAULT NULL,
  `num_forks` int DEFAULT NULL,
  `num_issues` int DEFAULT NULL,
  `num_closed_issues` int DEFAULT NULL,
  `num_pulls` int DEFAULT NULL,
  `num_closed_pulls` int DEFAULT NULL,
  `num_milestones` int NOT NULL DEFAULT '0',
  `num_closed_milestones` int NOT NULL DEFAULT '0',
  `is_private` tinyint(1) DEFAULT NULL,
  `is_bare` tinyint(1) DEFAULT NULL,
  `is_mirror` tinyint(1) DEFAULT NULL,
  `enable_wiki` tinyint(1) NOT NULL DEFAULT '1',
  `allow_public_wiki` tinyint(1) DEFAULT NULL,
  `enable_external_wiki` tinyint(1) DEFAULT NULL,
  `external_wiki_url` varchar(255) DEFAULT NULL,
  `enable_issues` tinyint(1) NOT NULL DEFAULT '1',
  `allow_public_issues` tinyint(1) DEFAULT NULL,
  `enable_external_tracker` tinyint(1) DEFAULT NULL,
  `external_tracker_url` varchar(255) DEFAULT NULL,
  `external_tracker_format` varchar(255) DEFAULT NULL,
  `external_tracker_style` varchar(255) DEFAULT NULL,
  `enable_pulls` tinyint(1) NOT NULL DEFAULT '1',
  `pulls_ignore_whitespace` tinyint(1) NOT NULL DEFAULT '0',
  `pulls_allow_rebase` tinyint(1) NOT NULL DEFAULT '0',
  `is_fork` tinyint(1) NOT NULL DEFAULT '0',
  `fork_id` bigint DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  `is_unlisted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_repository_s` (`owner_id`,`lower_name`),
  KEY `IDX_repository_lower_name` (`lower_name`),
  KEY `IDX_repository_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository`
--

LOCK TABLES `repository` WRITE;
/*!40000 ALTER TABLE `repository` DISABLE KEYS */;
INSERT INTO `repository` VALUES (2,2,'autoloading','autoloading','类及别名的自动加载','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572916822,1573007663,0),(3,2,'cache','cache','缓存设置','','master',45056,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572932637,1573007753,0),(4,2,'config','config','配置项获取','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572933449,1573007189,0),(5,2,'console','console','命令行支持','','master',28672,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572934163,1573007566,0),(6,2,'container','container','依赖注入容器组件','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572934588,1573007768,0),(7,2,'database','database','数据库组件','','master',65536,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935246,1573007544,0),(8,2,'encryption','encryption','加密解密','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935497,1573007737,0),(9,2,'error','error','错误处理','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935693,1573007607,0),(10,2,'foundation','foundation','框架基础','','master',24576,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935763,1573007522,0),(11,2,'http','http','REST API http 请求、响应类','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935869,1573007588,0),(12,2,'ip-location','ip-location','查询 IP 地址所在地','','master',4984832,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935925,1573007722,0),(13,2,'log','log','日志记录','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572935978,1573007624,0),(14,2,'mail','mail','邮件发送类','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936055,1573007784,0),(15,2,'pagination','pagination','分页组件','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936188,1573007705,0),(16,2,'provider-basic','provider-basic','','','master',24576,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936266,1572936285,0),(17,2,'provider-core','provider-core','','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936334,1572936338,0),(18,2,'provider-db','provider-db','','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936414,1572936438,0),(19,2,'provider-rest','provider-rest','','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936499,1572936502,0),(20,2,'provider-web','provider-web','','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936560,1572936565,0),(21,2,'rest','rest','REST API应用基础','','master',61440,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936647,1573007265,0),(22,2,'statical','statical','静态调用 Service 支持','','master',28672,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936687,1573007140,0),(23,2,'utility','utility','工具类','','master',36864,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572936745,1573007682,0),(24,2,'validator','validator','数据验证组件','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937138,1573007247,0),(25,2,'view','view','视图层','','master',24576,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937180,1573007640,0),(26,2,'web','web','传统应用Application组件','','master',24576,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937284,1573007206,0),(27,3,'alias-auto-complete','alias-auto-complete','Firefly框架中用到的类的别名的自动完成支持','','master',49152,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937636,1573008039,0),(28,3,'framework','framework','框架组件粘合代码','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937863,1573008151,0),(29,3,'project-cli','project-cli','单纯命令行应用示例代码','','master',163840,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572937981,1573008087,0),(30,3,'project-db','project-db','单纯db查询示例代码','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938033,1573008071,0),(31,3,'project-mweb','project-mweb','一个代码库对应多个普通WEB站点示例代码','','master',200704,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938091,1573008102,0),(32,3,'project-rest','project-rest','REST API应用示例代码','','master',225280,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938145,1573008113,0),(33,3,'project-web','project-web','普通WEB应用示例代码','','master',188416,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938198,1573008131,0),(34,3,'satis-config','satis-config','satic composer 静态库配置文件','','master',24576,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938247,1713129953,0),(35,3,'skeleton','skeleton','Firefly 开发框架示例应用','','master',233472,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572938312,1573008021,0),(36,4,'browser','browser','浏览器相关','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945369,1573007961,0),(37,4,'company','company','欣欣旅游公司相关信息','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945433,1573007975,0),(38,4,'ip','ip','','','master',4894720,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945493,1572945499,0),(39,4,'rpc','rpc','','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945543,1572945557,0),(40,4,'session','session','','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945602,1572945607,0),(41,4,'ubb','ubb','','','master',16384,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1572945641,1572945644,0),(43,4,'foundation','foundation','','','master',143360,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1597753528,1597758622,0),(44,4,'api','api','','','master',53248,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1597759558,1600155930,0),(45,1,'erp_doraemon','erp_doraemon','','','master',44360704,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1598581514,1749297273,0),(46,5,'foundation','foundation','','','master',131072,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1599214964,1599215035,0),(47,3,'satis-config-local','satis-config-local','','','master',12288,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1599222746,1599222778,0),(48,5,'trade','trade','','','master',50176,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1599310100,1599310224,0),(49,5,'gds','gds','','','master',245760,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1599310258,1599310268,0),(50,1,'satis-config','satis-config','','','master',40960,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1600155226,1600155594,0),(51,6,'conf.d','conf.d','','','master',36864,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602299370,1602299370,0),(52,1,'firefly_doc','firefly_doc','','','master',917504,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602318287,1602318287,0),(53,6,'chat.cncn.com','chat.cncn.com','','','master',6970368,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602318826,1602318826,0),(54,6,'api_new_v2','api_new_v2','','','master',1715200,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602319072,1602319072,0),(55,6,'rpc','rpc','','','master',790528,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602319242,1602319242,0),(56,6,'erp','erp','','','master',44113920,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1602319338,1602319338,0),(57,6,'php-standards','php-standards','','','master',409600,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1603521559,1603521559,0),(58,6,'git_usage','git_usage','','','master',57184256,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1603521734,1603521734,0),(59,6,'cncn_api_sdk','cncn_api_sdk','','','master',20480,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1603521877,1603521877,0),(60,6,'api_guide','api_guide','','','master',229376,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1603521951,1603521951,0),(61,7,'phpcode','phpcode','','','master',4947968,0,2,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1713111320,1713111377,0),(64,1,'qgsc','qgsc','','','master',14465024,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1740408520,1744760394,0),(65,1,'test','test','','','master',1254400,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1742545238,1742545310,0),(70,1,'rsync','rsync','','','master',105472,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,'',1,0,0,'','','numeric',1,0,0,0,0,1749297097,1749297498,0);
/*!40000 ALTER TABLE `repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `star`
--

DROP TABLE IF EXISTS `star`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `star` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_star_s` (`uid`,`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `star`
--

LOCK TABLES `star` WRITE;
/*!40000 ALTER TABLE `star` DISABLE KEYS */;
/*!40000 ALTER TABLE `star` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `org_id` bigint DEFAULT NULL,
  `lower_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `authorize` int DEFAULT NULL,
  `num_repos` int DEFAULT NULL,
  `num_members` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_team_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,2,'owners','Owners','',4,25,1),(2,3,'owners','Owners','',4,10,1),(3,4,'owners','Owners','',4,8,1),(4,5,'owners','Owners','',4,3,1),(5,6,'owners','Owners','',4,9,1),(6,7,'owners','Owners','',4,1,1);
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_repo`
--

DROP TABLE IF EXISTS `team_repo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_repo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `org_id` bigint DEFAULT NULL,
  `team_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_repo_s` (`team_id`,`repo_id`),
  KEY `IDX_team_repo_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_repo`
--

LOCK TABLES `team_repo` WRITE;
/*!40000 ALTER TABLE `team_repo` DISABLE KEYS */;
INSERT INTO `team_repo` VALUES (1,2,1,2),(2,2,1,3),(3,2,1,4),(4,2,1,5),(5,2,1,6),(6,2,1,7),(7,2,1,8),(8,2,1,9),(9,2,1,10),(10,2,1,11),(11,2,1,12),(12,2,1,13),(13,2,1,14),(14,2,1,15),(15,2,1,16),(16,2,1,17),(17,2,1,18),(18,2,1,19),(19,2,1,20),(20,2,1,21),(21,2,1,22),(22,2,1,23),(23,2,1,24),(24,2,1,25),(25,2,1,26),(26,3,2,27),(27,3,2,28),(28,3,2,29),(29,3,2,30),(30,3,2,31),(31,3,2,32),(32,3,2,33),(33,3,2,34),(34,3,2,35),(35,4,3,36),(36,4,3,37),(37,4,3,38),(38,4,3,39),(39,4,3,40),(40,4,3,41),(41,4,3,43),(42,4,3,44),(43,5,4,46),(44,3,2,47),(45,5,4,48),(46,5,4,49),(47,6,5,51),(48,6,5,53),(49,6,5,54),(50,6,5,55),(51,6,5,56),(52,6,5,57),(53,6,5,58),(54,6,5,59),(55,6,5,60),(56,7,6,61);
/*!40000 ALTER TABLE `team_repo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_user`
--

DROP TABLE IF EXISTS `team_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `org_id` bigint DEFAULT NULL,
  `team_id` bigint DEFAULT NULL,
  `uid` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_user_s` (`team_id`,`uid`),
  KEY `IDX_team_user_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_user`
--

LOCK TABLES `team_user` WRITE;
/*!40000 ALTER TABLE `team_user` DISABLE KEYS */;
INSERT INTO `team_user` VALUES (1,2,1,1),(2,3,2,1),(3,4,3,1),(4,5,4,1),(5,6,5,1),(6,7,6,1);
/*!40000 ALTER TABLE `team_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor`
--

DROP TABLE IF EXISTS `two_factor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_two_factor_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor`
--

LOCK TABLES `two_factor` WRITE;
/*!40000 ALTER TABLE `two_factor` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_recovery_code`
--

DROP TABLE IF EXISTS `two_factor_recovery_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_recovery_code` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `code` varchar(11) DEFAULT NULL,
  `is_used` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_recovery_code`
--

LOCK TABLES `two_factor_recovery_code` WRITE;
/*!40000 ALTER TABLE `two_factor_recovery_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_recovery_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upload`
--

DROP TABLE IF EXISTS `upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `upload` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_upload_uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upload`
--

LOCK TABLES `upload` WRITE;
/*!40000 ALTER TABLE `upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lower_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `login_type` int DEFAULT NULL,
  `login_source` bigint NOT NULL DEFAULT '0',
  `login_name` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `rands` varchar(10) DEFAULT NULL,
  `salt` varchar(10) DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  `last_repo_visibility` tinyint(1) DEFAULT NULL,
  `max_repo_creation` int NOT NULL DEFAULT '-1',
  `is_active` tinyint(1) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `allow_git_hook` tinyint(1) DEFAULT NULL,
  `allow_import_local` tinyint(1) DEFAULT NULL,
  `prohibit_login` tinyint(1) DEFAULT NULL,
  `avatar` varchar(2048) NOT NULL,
  `avatar_email` varchar(255) NOT NULL,
  `use_custom_avatar` tinyint(1) DEFAULT NULL,
  `num_followers` int DEFAULT NULL,
  `num_following` int NOT NULL DEFAULT '0',
  `num_stars` int DEFAULT NULL,
  `num_repos` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `num_teams` int DEFAULT NULL,
  `num_members` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_lower_name` (`lower_name`),
  UNIQUE KEY `UQE_user_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'chenms','chenms','','ameiurl@gmail.com','5c8c838097dfa9609e5ab8d3ae4cae7807b7cb1982fb4a0063915429200200cb8f6bd738e57b8294f9dcdc74193ea44adb69',0,0,'',0,'','','gQcWyMhpwi','R0lD7W7rrI',1572862510,1749297097,0,-1,1,1,0,0,0,'591ec3a389a0f16168be10d3e4d81907','ameiurl@gmail.com',0,0,0,0,6,'',0,0),(2,'butterfly','butterfly','','','',0,0,'',1,'','','hXxmk0qMiJ','GpNvlpRGrC',1572916725,1573007923,0,-1,1,0,0,0,0,'','',1,0,0,0,25,'firefly 框架的基础组件库',1,1),(3,'firefly','firefly','','','',0,0,'',1,'','','i9vOUF5eqc','ep1arI0D1S',1572937587,1599222746,0,-1,1,0,0,0,0,'','',1,0,0,0,10,'Firefly 开发框架',1,1),(4,'dragonfly','dragonfly','','','',0,0,'',1,'','','6rPA588F4E','HiezNX0x19',1572945048,1597759558,0,-1,1,0,0,0,0,'','',1,0,0,0,8,'业务逻辑相关的通用公共代码',1,1),(5,'ddd','ddd','','','',0,0,'',1,'','','rPJjqujyRf','eiFuHWSh8C',1599214939,1599310258,0,-1,1,0,0,0,0,'','',1,0,0,0,3,'',1,1),(6,'cncn','cncn','','','',NULL,0,'',1,'','','PEI6POhSa9','iGIJciPkw4',1602299344,1603521951,0,-1,1,0,0,0,0,'','',1,0,0,0,9,'',1,1),(7,'backup','backup','','','',NULL,0,'',1,'','','CSxRbTqNg5','etEO7BUpxh',0,1713111320,0,-1,1,0,0,0,0,'','',1,0,0,0,1,'',1,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (1,22);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watch`
--

DROP TABLE IF EXISTS `watch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `watch` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `repo_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_watch_watch` (`user_id`,`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watch`
--

LOCK TABLES `watch` WRITE;
/*!40000 ALTER TABLE `watch` DISABLE KEYS */;
INSERT INTO `watch` VALUES (2,1,2),(4,1,3),(6,1,4),(8,1,5),(10,1,6),(12,1,7),(14,1,8),(16,1,9),(18,1,10),(20,1,11),(22,1,12),(24,1,13),(26,1,14),(28,1,15),(30,1,16),(32,1,17),(34,1,18),(36,1,19),(38,1,20),(40,1,21),(42,1,22),(44,1,23),(46,1,24),(48,1,25),(50,1,26),(52,1,27),(54,1,28),(56,1,29),(58,1,30),(60,1,31),(62,1,32),(64,1,33),(66,1,34),(68,1,35),(70,1,36),(72,1,37),(74,1,38),(76,1,39),(78,1,40),(80,1,41),(83,1,43),(85,1,44),(87,1,45),(88,1,46),(90,1,47),(92,1,48),(94,1,49),(96,1,50),(97,1,51),(99,1,52),(100,1,53),(102,1,54),(104,1,55),(106,1,56),(108,1,57),(110,1,58),(112,1,59),(114,1,60),(116,1,61),(120,1,64),(121,1,65),(124,1,70),(3,2,2),(5,2,3),(7,2,4),(9,2,5),(11,2,6),(13,2,7),(15,2,8),(17,2,9),(19,2,10),(21,2,11),(23,2,12),(25,2,13),(27,2,14),(29,2,15),(31,2,16),(33,2,17),(35,2,18),(37,2,19),(39,2,20),(41,2,21),(43,2,22),(45,2,23),(47,2,24),(49,2,25),(51,2,26),(53,3,27),(55,3,28),(57,3,29),(59,3,30),(61,3,31),(63,3,32),(65,3,33),(67,3,34),(69,3,35),(91,3,47),(71,4,36),(73,4,37),(75,4,38),(77,4,39),(79,4,40),(81,4,41),(84,4,43),(86,4,44),(89,5,46),(93,5,48),(95,5,49),(98,6,51),(101,6,53),(103,6,54),(105,6,55),(107,6,56),(109,6,57),(111,6,58),(113,6,59),(115,6,60),(117,7,61);
/*!40000 ALTER TABLE `watch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook`
--

DROP TABLE IF EXISTS `webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repo_id` bigint DEFAULT NULL,
  `org_id` bigint DEFAULT NULL,
  `url` text,
  `content_type` int DEFAULT NULL,
  `secret` text,
  `events` text,
  `is_ssl` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `hook_task_type` int DEFAULT NULL,
  `meta` text,
  `last_status` int DEFAULT NULL,
  `created_unix` bigint DEFAULT NULL,
  `updated_unix` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook`
--

LOCK TABLES `webhook` WRITE;
/*!40000 ALTER TABLE `webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-13 10:00:00
